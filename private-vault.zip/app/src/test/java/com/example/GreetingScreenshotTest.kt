package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.screens.PinScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.PrivateVaultTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      PrivateVaultTheme {
        SplashScreen(isSoundEnabled = false, language = "en", onSplashFinished = {})
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }

  @Test
  fun pin_screen_screenshot() {
    composeTestRule.setContent {
      PrivateVaultTheme {
        PinScreen(
          isFirstTimeSetup = true,
          isSoundEnabled = false,
          isBiometricEnabled = false,
          language = "en",
          onSuccess = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/pin_setup.png")
  }

  @Test
  fun lock_screen_screenshot() {
    composeTestRule.setContent {
      PrivateVaultTheme {
        PinScreen(
          isFirstTimeSetup = false,
          isSoundEnabled = false,
          isBiometricEnabled = false,
          language = "en",
          onSuccess = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/lock_screen.png")
  }
}
