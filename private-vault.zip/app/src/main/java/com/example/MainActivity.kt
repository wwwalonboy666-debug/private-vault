package com.example

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.VaultScreen
import com.example.ui.VaultViewModel
import com.example.ui.components.AddMediaPickerSheet
import com.example.ui.components.ImportProgressDialog
import com.example.ui.components.PostImportDeleteOriginalDialog
import com.example.ui.screens.MediaGalleryScreen
import com.example.ui.screens.PhotoViewerScreen
import com.example.ui.screens.PinScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.VaultHomeScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.theme.PrivateVaultTheme

class MainActivity : FragmentActivity() {
    private val viewModel: VaultViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settingsRepo = viewModel.settingsRepository
            val isDarkMode by settingsRepo.isDarkMode.collectAsState()
            val isScreenshotProtected by settingsRepo.isScreenshotProtected.collectAsState()

            // Handle FLAG_SECURE dynamically based on screenshot protection setting
            LaunchedEffect(isScreenshotProtected) {
                try {
                    if (isScreenshotProtected) {
                        window.setFlags(
                            WindowManager.LayoutParams.FLAG_SECURE,
                            WindowManager.LayoutParams.FLAG_SECURE
                        )
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            PrivateVaultTheme(darkTheme = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = androidx.compose.material3.MaterialTheme.colorScheme.background
                ) {
                    Box(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
                        PrivateVaultApp(viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkAutoLock()
    }
}

@Composable
fun PrivateVaultApp(viewModel: VaultViewModel) {
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.checkAutoLock()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val currentScreen by viewModel.currentScreen.collectAsState()
    val settingsRepo = viewModel.settingsRepository
    val isBiometricEnabled by settingsRepo.isBiometricEnabled.collectAsState()
    val isSoundEnabled by settingsRepo.isSoundEnabled.collectAsState()
    val autoLockMs by settingsRepo.autoLockMs.collectAsState()
    val isDarkMode by settingsRepo.isDarkMode.collectAsState()
    val language by settingsRepo.language.collectAsState()
    val isScreenshotProtected by settingsRepo.isScreenshotProtected.collectAsState()

    val photos by viewModel.photos.collectAsState()
    val videos by viewModel.videos.collectAsState()
    val photosCount by viewModel.photosCount.collectAsState()
    val videosCount by viewModel.videosCount.collectAsState()
    val totalBytes by viewModel.totalBytes.collectAsState()

    val importProgress by viewModel.importProgress.collectAsState()
    val pendingDeleteOriginals by viewModel.pendingDeleteOriginalUris.collectAsState()
    val activePhoto by viewModel.activePhoto.collectAsState()
    val activeVideo by viewModel.activeVideo.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()

    var showAddMediaSheet by remember { mutableStateOf(false) }

    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(userMessage) {
        userMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    // Back handling
    BackHandler(enabled = currentScreen != VaultScreen.SPLASH && currentScreen != VaultScreen.LOCK_SCREEN) {
        when (currentScreen) {
            VaultScreen.PHOTO_VIEWER -> viewModel.navigateTo(VaultScreen.GALLERY_PHOTOS)
            VaultScreen.VIDEO_PLAYER -> viewModel.navigateTo(VaultScreen.GALLERY_VIDEOS)
            VaultScreen.GALLERY_PHOTOS, VaultScreen.GALLERY_VIDEOS, VaultScreen.SETTINGS -> {
                viewModel.navigateTo(VaultScreen.HOME)
            }
            VaultScreen.PIN_SETUP -> {
                // Exit or minimize
                (context as? android.app.Activity)?.finish()
            }
            VaultScreen.HOME -> {
                (context as? android.app.Activity)?.finish()
            }
            else -> {}
        }
    }

    AnimatedContent(
        targetState = currentScreen,
        modifier = Modifier.fillMaxSize(),
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            VaultScreen.SPLASH -> {
                SplashScreen(
                    isSoundEnabled = isSoundEnabled,
                    language = language,
                    onSplashFinished = { viewModel.onSplashFinished() }
                )
            }

            VaultScreen.PIN_SETUP -> {
                PinScreen(
                    isFirstTimeSetup = true,
                    isSoundEnabled = isSoundEnabled,
                    isBiometricEnabled = isBiometricEnabled,
                    language = language,
                    onSuccess = { viewModel.onPinSuccess() }
                )
            }

            VaultScreen.LOCK_SCREEN -> {
                PinScreen(
                    isFirstTimeSetup = false,
                    isSoundEnabled = isSoundEnabled,
                    isBiometricEnabled = isBiometricEnabled,
                    language = language,
                    onSuccess = { viewModel.onPinSuccess() }
                )
            }

            VaultScreen.HOME -> {
                VaultHomeScreen(
                    photosCount = photosCount,
                    videosCount = videosCount,
                    totalBytes = totalBytes,
                    language = language,
                    onOpenPhotos = { viewModel.navigateTo(VaultScreen.GALLERY_PHOTOS) },
                    onOpenVideos = { viewModel.navigateTo(VaultScreen.GALLERY_VIDEOS) },
                    onAddMedia = { showAddMediaSheet = true },
                    onOpenSettings = { viewModel.navigateTo(VaultScreen.SETTINGS) },
                    onLockNow = { viewModel.lockNow() }
                )
            }

            VaultScreen.GALLERY_PHOTOS -> {
                MediaGalleryScreen(
                    mediaType = "PHOTO",
                    mediaList = photos,
                    repository = viewModel.repository,
                    language = language,
                    onBack = { viewModel.navigateTo(VaultScreen.HOME) },
                    onOpenMedia = { viewModel.openPhotoViewer(it) },
                    onAddMedia = { showAddMediaSheet = true },
                    onRestoreBatch = { viewModel.restoreBatch(it) },
                    onDeleteBatch = { viewModel.deleteBatch(it) }
                )
            }

            VaultScreen.GALLERY_VIDEOS -> {
                MediaGalleryScreen(
                    mediaType = "VIDEO",
                    mediaList = videos,
                    repository = viewModel.repository,
                    language = language,
                    onBack = { viewModel.navigateTo(VaultScreen.HOME) },
                    onOpenMedia = { viewModel.openVideoPlayer(it) },
                    onAddMedia = { showAddMediaSheet = true },
                    onRestoreBatch = { viewModel.restoreBatch(it) },
                    onDeleteBatch = { viewModel.deleteBatch(it) }
                )
            }

            VaultScreen.PHOTO_VIEWER -> {
                activePhoto?.let { photo ->
                    PhotoViewerScreen(
                        media = photo,
                        repository = viewModel.repository,
                        language = language,
                        onBack = { viewModel.navigateTo(VaultScreen.GALLERY_PHOTOS) },
                        onRestore = { viewModel.restoreSingleMedia(it) },
                        onDelete = { viewModel.deleteSingleMedia(it) }
                    )
                } ?: run {
                    viewModel.navigateTo(VaultScreen.GALLERY_PHOTOS)
                }
            }

            VaultScreen.VIDEO_PLAYER -> {
                activeVideo?.let { video ->
                    VideoPlayerScreen(
                        media = video,
                        repository = viewModel.repository,
                        language = language,
                        onBack = { viewModel.navigateTo(VaultScreen.GALLERY_VIDEOS) },
                        onRestore = { viewModel.restoreSingleMedia(it) },
                        onDelete = { viewModel.deleteSingleMedia(it) }
                    )
                } ?: run {
                    viewModel.navigateTo(VaultScreen.GALLERY_VIDEOS)
                }
            }

            VaultScreen.SETTINGS -> {
                SettingsScreen(
                    settingsRepository = settingsRepo,
                    isBiometricEnabled = isBiometricEnabled,
                    autoLockMs = autoLockMs,
                    isSoundEnabled = isSoundEnabled,
                    isDarkMode = isDarkMode,
                    language = language,
                    isScreenshotProtected = isScreenshotProtected,
                    onBack = { viewModel.navigateTo(VaultScreen.HOME) }
                )
            }
        }
    }

    // Modal BottomSheet for Adding Media
    if (showAddMediaSheet) {
        AddMediaPickerSheet(
            language = language,
            onDismiss = { showAddMediaSheet = false },
            onUrisSelected = { uris ->
                viewModel.importUris(uris)
            }
        )
    }

    // Progress Dialog during encryption
    importProgress?.let { (current, total) ->
        ImportProgressDialog(
            current = current,
            total = total,
            language = language
        )
    }

    // Prompt to optionally delete originals after verified encryption
    pendingDeleteOriginals?.let { uris ->
        PostImportDeleteOriginalDialog(
            count = uris.size,
            language = language,
            onKeepOriginal = { viewModel.dismissDeleteOriginalsPrompt() },
            onDeleteOriginal = { viewModel.confirmDeleteOriginals(context) }
        )
    }
}
