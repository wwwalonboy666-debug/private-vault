package com.example.util

import android.graphics.Bitmap
import android.util.LruCache

object ThumbnailCache {
    // Cache up to ~150 thumbnails or 20 MB max
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = (maxMemory / 8).coerceIn(10 * 1024, 30 * 1024) // in KB

    private val lruCache = object : LruCache<Long, Bitmap>(cacheSize) {
        override fun sizeOf(key: Long, bitmap: Bitmap): Int {
            return (bitmap.byteCount / 1024).coerceAtLeast(1)
        }
    }

    fun get(id: Long): Bitmap? {
        return synchronized(this) {
            lruCache.get(id)
        }
    }

    fun put(id: Long, bitmap: Bitmap) {
        synchronized(this) {
            lruCache.put(id, bitmap)
        }
    }

    fun remove(id: Long) {
        synchronized(this) {
            lruCache.remove(id)
        }
    }

    fun clear() {
        synchronized(this) {
            lruCache.evictAll()
        }
    }
}
