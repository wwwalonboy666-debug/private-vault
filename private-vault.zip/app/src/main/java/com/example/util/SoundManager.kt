package com.example.util

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.exp
import kotlin.math.sin

object SoundManager {
    private val scope = CoroutineScope(Dispatchers.Default)

    // Pre-synthesized PCM buffer for a crisp, subtle digital tap
    private val clickPcmData: ByteArray by lazy {
        val sampleRate = 44100
        val durationSec = 0.025 // 25 milliseconds
        val numSamples = (durationSec * sampleRate).toInt()
        val buffer = ShortArray(numSamples)
        val freq = 1400.0 // crisp frequency

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            // Exponential decay envelope for a clean tactile click
            val envelope = exp(-t * 220.0)
            val sample = (sin(2.0 * Math.PI * freq * t) * envelope * 0.45 * Short.MAX_VALUE).toInt()
            buffer[i] = sample.toShort().coerceIn(Short.MIN_VALUE, Short.MAX_VALUE)
        }

        val byteBuffer = ByteArray(numSamples * 2)
        for (i in 0 until numSamples) {
            byteBuffer[i * 2] = (buffer[i].toInt() and 0xFF).toByte()
            byteBuffer[i * 2 + 1] = ((buffer[i].toInt() shr 8) and 0xFF).toByte()
        }
        byteBuffer
    }

    fun playKeypadClick(isEnabled: Boolean) {
        if (!isEnabled) return
        scope.launch {
            try {
                val sampleRate = 44100
                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(clickPcmData.size)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(clickPcmData, 0, clickPcmData.size)
                audioTrack.play()
                // Auto release after sound finishes
                Thread.sleep(35)
                audioTrack.stop()
                audioTrack.release()
            } catch (_: Exception) {
                // Ignore audio track edge failure gracefully
            }
        }
    }

    fun playSplashTone(isEnabled: Boolean) {
        if (!isEnabled) return
        scope.launch {
            try {
                val sampleRate = 44100
                val durationSec = 0.12 // 120ms subtle soft chime
                val numSamples = (durationSec * sampleRate).toInt()
                val byteBuffer = ByteArray(numSamples * 2)

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val envelope = exp(-t * 35.0)
                    val s1 = sin(2.0 * Math.PI * 880.0 * t)
                    val s2 = sin(2.0 * Math.PI * 1320.0 * t) * 0.5
                    val sample = ((s1 + s2) * envelope * 0.35 * Short.MAX_VALUE).toInt()
                    val shortVal = sample.toShort().coerceIn(Short.MIN_VALUE, Short.MAX_VALUE)
                    byteBuffer[i * 2] = (shortVal.toInt() and 0xFF).toByte()
                    byteBuffer[i * 2 + 1] = ((shortVal.toInt() shr 8) and 0xFF).toByte()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(byteBuffer.size)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(byteBuffer, 0, byteBuffer.size)
                audioTrack.play()
                Thread.sleep(150)
                audioTrack.stop()
                audioTrack.release()
            } catch (_: Exception) {
            }
        }
    }
}
