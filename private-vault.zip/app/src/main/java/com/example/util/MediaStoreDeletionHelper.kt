package com.example.util

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

sealed class DeletionResult {
    data class Completed(val successCount: Int, val totalCount: Int) : DeletionResult()
    data class RequiresUserConsent(val intentSender: IntentSender, val uris: List<Uri>) : DeletionResult()
    data class Error(val message: String) : DeletionResult()
}

object MediaStoreDeletionHelper {

    fun isUriExisting(context: Context, uri: Uri): Boolean {
        return try {
            context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns._ID), null, null, null)?.use { cursor ->
                cursor.moveToFirst()
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Attempts to delete original media files from device storage.
     * Supports Android 10 (API 29) RecoverableSecurityException,
     * Android 11+ (API 30+) MediaStore.createDeleteRequest,
     * and legacy direct deletion.
     */
    fun prepareDeletion(context: Context, uris: List<Uri>): DeletionResult {
        if (uris.isEmpty()) {
            return DeletionResult.Completed(0, 0)
        }

        // On Android 11+ (API 30+), MediaStore provides createDeleteRequest for batch consent
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val mediaStoreUris = uris.filter { uri ->
                val auth = uri.authority
                auth == "media" || auth?.contains("media", ignoreCase = true) == true
            }

            if (mediaStoreUris.isNotEmpty()) {
                return try {
                    val pendingIntent = MediaStore.createDeleteRequest(context.contentResolver, mediaStoreUris)
                    DeletionResult.RequiresUserConsent(pendingIntent.intentSender, mediaStoreUris)
                } catch (e: Exception) {
                    e.printStackTrace()
                    // Fall back to direct delete attempt
                    directDeleteUris(context, uris)
                }
            }
        }

        // Android 10 or legacy: try direct delete and catch RecoverableSecurityException
        return directDeleteUris(context, uris)
    }

    private fun directDeleteUris(context: Context, uris: List<Uri>): DeletionResult {
        var deletedCount = 0
        for (uri in uris) {
            try {
                val rows = context.contentResolver.delete(uri, null, null)
                if (rows > 0) {
                    deletedCount++
                }
            } catch (e: Exception) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && e is RecoverableSecurityException) {
                    val intentSender = e.userAction.actionIntent.intentSender
                    return DeletionResult.RequiresUserConsent(intentSender, listOf(uri))
                } else {
                    e.printStackTrace()
                }
            }
        }
        return DeletionResult.Completed(deletedCount, uris.size)
    }

    fun verifyUrisDeleted(context: Context, uris: List<Uri>): Int {
        var deletedCount = 0
        for (uri in uris) {
            if (!isUriExisting(context, uri)) {
                deletedCount++
            }
        }
        return deletedCount
    }
}
