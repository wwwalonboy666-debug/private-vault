package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("private_vault_user_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
        private const val KEY_AUTO_LOCK_MS = "auto_lock_ms"
        private const val KEY_SOUND_ENABLED = "sound_enabled"
        private const val KEY_DARK_MODE = "dark_mode"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_SCREENSHOT_PROTECTED = "screenshot_protected_v2"

        const val AUTO_LOCK_IMMEDIATELY = 0L
        const val AUTO_LOCK_1_MIN = 60_000L
        const val AUTO_LOCK_5_MIN = 300_000L
        const val AUTO_LOCK_10_MIN = 600_000L
    }

    private val _isBiometricEnabled = MutableStateFlow(prefs.getBoolean(KEY_BIOMETRIC_ENABLED, true))
    val isBiometricEnabled: StateFlow<Boolean> = _isBiometricEnabled.asStateFlow()

    private val _autoLockMs = MutableStateFlow(prefs.getLong(KEY_AUTO_LOCK_MS, AUTO_LOCK_1_MIN))
    val autoLockMs: StateFlow<Long> = _autoLockMs.asStateFlow()

    private val _isSoundEnabled = MutableStateFlow(prefs.getBoolean(KEY_SOUND_ENABLED, true))
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled.asStateFlow()

    private val _isDarkMode = MutableStateFlow(prefs.getBoolean(KEY_DARK_MODE, true))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _language = MutableStateFlow(prefs.getString(KEY_LANGUAGE, "en") ?: "en")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _isScreenshotProtected = MutableStateFlow(prefs.getBoolean(KEY_SCREENSHOT_PROTECTED, false))
    val isScreenshotProtected: StateFlow<Boolean> = _isScreenshotProtected.asStateFlow()

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
        _isBiometricEnabled.value = enabled
    }

    fun setAutoLockMs(ms: Long) {
        prefs.edit().putLong(KEY_AUTO_LOCK_MS, ms).apply()
        _autoLockMs.value = ms
    }

    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()
        _isSoundEnabled.value = enabled
    }

    fun setDarkMode(isDark: Boolean) {
        prefs.edit().putBoolean(KEY_DARK_MODE, isDark).apply()
        _isDarkMode.value = isDark
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString(KEY_LANGUAGE, lang).apply()
        _language.value = lang
    }

    fun setScreenshotProtected(protected: Boolean) {
        prefs.edit().putBoolean(KEY_SCREENSHOT_PROTECTED, protected).apply()
        _isScreenshotProtected.value = protected
    }
}
