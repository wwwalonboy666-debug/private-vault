package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_media")
data class VaultMediaEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val mediaType: String, // "PHOTO" or "VIDEO"
    val originalFileName: String,
    val mimeType: String,
    val fileSize: Long,
    val encryptedFileName: String,
    val thumbnailFileName: String?,
    val durationMs: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
