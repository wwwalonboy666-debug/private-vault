package com.example.data

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.example.data.dao.VaultMediaDao
import com.example.data.model.VaultMediaEntity
import com.example.security.CryptoManager
import com.example.util.ThumbnailCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class VaultRepository(
    private val context: Context,
    private val dao: VaultMediaDao
) {
    private val mediaDir = File(context.filesDir, "vault/media").apply { mkdirs() }
    private val thumbsDir = File(context.filesDir, "vault/thumbs").apply { mkdirs() }

    val allPhotos: Flow<List<VaultMediaEntity>> = dao.getMediaByType("PHOTO")
    val allVideos: Flow<List<VaultMediaEntity>> = dao.getMediaByType("VIDEO")
    val photosCount: Flow<Int> = dao.getPhotosCount()
    val videosCount: Flow<Int> = dao.getVideosCount()
    val totalBytes: Flow<Long?> = dao.getTotalBytes()

    sealed class ImportResult {
        data class Success(val media: VaultMediaEntity, val originalUri: Uri) : ImportResult()
        data class Failure(val originalUri: Uri, val error: String) : ImportResult()
    }

    suspend fun importMedia(
        uri: Uri,
        onProgress: ((bytesRead: Long, totalBytes: Long) -> Unit)? = null
    ): ImportResult = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            var fileName = "vault_media_${System.currentTimeMillis()}"
            var fileSize = 0L

            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex != -1) {
                        fileName = cursor.getString(nameIndex) ?: fileName
                    }
                    if (sizeIndex != -1) {
                        fileSize = cursor.getLong(sizeIndex)
                    }
                }
            }

            val mimeType = contentResolver.getType(uri) ?: when {
                fileName.endsWith(".mp4", ignoreCase = true) -> "video/mp4"
                fileName.endsWith(".mov", ignoreCase = true) -> "video/quicktime"
                fileName.endsWith(".mkv", ignoreCase = true) -> "video/x-matroska"
                fileName.endsWith(".png", ignoreCase = true) -> "image/png"
                fileName.endsWith(".webp", ignoreCase = true) -> "image/webp"
                else -> "image/jpeg"
            }

            val isVideo = mimeType.startsWith("video/")
            val mediaType = if (isVideo) "VIDEO" else "PHOTO"

            var durationMs = 0L
            if (isVideo) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    val timeStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    durationMs = timeStr?.toLongOrNull() ?: 0L
                } catch (_: Exception) {
                } finally {
                    try { retriever.release() } catch (_: Exception) {}
                }
            }

            val fileUuid = UUID.randomUUID().toString()
            val encFileName = "$fileUuid.enc"
            val thumbFileName = "$fileUuid.thumb"
            val encDestFile = File(mediaDir, encFileName)
            val thumbDestFile = File(thumbsDir, thumbFileName)

            // Step 1: Encrypt stream using chunked streaming encryption for videos and buffered encryption for photos
            contentResolver.openInputStream(uri)?.use { stream ->
                if (isVideo) {
                    CryptoManager.encryptStreamChunked(
                        inputStream = stream,
                        destinationFile = encDestFile,
                        estimatedTotalBytes = fileSize,
                        onProgress = onProgress
                    )
                } else {
                    CryptoManager.encryptStreamToFile(
                        inputStream = stream,
                        destinationFile = encDestFile,
                        totalBytes = fileSize,
                        onProgress = onProgress
                    )
                }
            } ?: throw IllegalStateException("Cannot read source media stream")

            if (fileSize == 0L) {
                fileSize = encDestFile.length()
            }

            // Step 2: Verify encrypted file integrity
            val isVerified = CryptoManager.verifyEncryptedFile(encDestFile)
            if (!isVerified) {
                encDestFile.delete()
                return@withContext ImportResult.Failure(uri, "Integrity verification failed for encrypted file")
            }

            // Step 3: Create encrypted thumbnail
            val thumbCreated = CryptoManager.createEncryptedThumbnail(context, uri, isVideo, thumbDestFile)

            // Step 4: Save metadata to Room database
            val entity = VaultMediaEntity(
                mediaType = mediaType,
                originalFileName = fileName,
                mimeType = mimeType,
                fileSize = fileSize,
                encryptedFileName = encFileName,
                thumbnailFileName = if (thumbCreated) thumbFileName else null,
                durationMs = durationMs
            )
            val insertedId = dao.insertMedia(entity)
            val savedEntity = entity.copy(id = insertedId)

            ImportResult.Success(savedEntity, uri)
        } catch (e: Exception) {
            e.printStackTrace()
            ImportResult.Failure(uri, e.message ?: "Unknown import error")
        }
    }

    suspend fun restoreMedia(media: VaultMediaEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val encFile = File(mediaDir, media.encryptedFileName)
            if (!encFile.exists()) return@withContext false

            val contentResolver = context.contentResolver
            val isVideo = media.mediaType == "VIDEO"
            val contentUri = if (isVideo) {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, media.originalFileName)
                put(MediaStore.MediaColumns.MIME_TYPE, media.mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val relativePath = if (isVideo) {
                        Environment.DIRECTORY_MOVIES + "/Restored"
                    } else {
                        Environment.DIRECTORY_PICTURES + "/Restored"
                    }
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }

            val insertedUri = contentResolver.insert(contentUri, contentValues)
                ?: return@withContext false

            var success = false
            try {
                contentResolver.openOutputStream(insertedUri)?.use { outputStream ->
                    CryptoManager.decryptFileToStream(encFile, outputStream)
                    success = true
                }
            } catch (e: Exception) {
                contentResolver.delete(insertedUri, null, null)
                throw e
            }

            if (success) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val updateValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.IS_PENDING, 0)
                    }
                    contentResolver.update(insertedUri, updateValues, null, null)
                }

                // Remove vault copy only after verified restore
                encFile.delete()
                media.thumbnailFileName?.let { File(thumbsDir, it).delete() }
                ThumbnailCache.remove(media.id)
                dao.deleteMedia(media)
                return@withContext true
            } else {
                return@withContext false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun deleteMedia(media: VaultMediaEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val encFile = File(mediaDir, media.encryptedFileName)
            if (encFile.exists()) encFile.delete()
            media.thumbnailFileName?.let {
                val thumbFile = File(thumbsDir, it)
                if (thumbFile.exists()) thumbFile.delete()
            }
            ThumbnailCache.remove(media.id)
            dao.deleteMedia(media)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun deleteBatch(mediaList: List<VaultMediaEntity>): Int = withContext(Dispatchers.IO) {
        var count = 0
        mediaList.forEach { item ->
            if (deleteMedia(item)) count++
        }
        count
    }

    fun getEncryptedFile(media: VaultMediaEntity): File {
        return File(mediaDir, media.encryptedFileName)
    }

    fun getThumbnailFile(media: VaultMediaEntity): File? {
        return media.thumbnailFileName?.let { File(thumbsDir, it) }
    }
}
