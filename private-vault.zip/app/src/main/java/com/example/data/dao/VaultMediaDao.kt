package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.VaultMediaEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultMediaDao {
    @Query("SELECT * FROM vault_media ORDER BY createdAt DESC")
    fun getAllMedia(): Flow<List<VaultMediaEntity>>

    @Query("SELECT * FROM vault_media WHERE mediaType = :type ORDER BY createdAt DESC")
    fun getMediaByType(type: String): Flow<List<VaultMediaEntity>>

    @Query("SELECT * FROM vault_media WHERE id = :id LIMIT 1")
    suspend fun getMediaById(id: Long): VaultMediaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedia(media: VaultMediaEntity): Long

    @Delete
    suspend fun deleteMedia(media: VaultMediaEntity)

    @Query("DELETE FROM vault_media WHERE id IN (:ids)")
    suspend fun deleteMediaByIds(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM vault_media WHERE mediaType = 'PHOTO'")
    fun getPhotosCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM vault_media WHERE mediaType = 'VIDEO'")
    fun getVideosCount(): Flow<Int>

    @Query("SELECT SUM(fileSize) FROM vault_media")
    fun getTotalBytes(): Flow<Long?>
}
