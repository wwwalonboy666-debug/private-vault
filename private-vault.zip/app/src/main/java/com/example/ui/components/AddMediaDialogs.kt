package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PermMedia
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.VaultBorder
import com.example.ui.theme.VaultCyanAccent
import com.example.ui.theme.VaultDarkCard
import com.example.ui.theme.VaultDarkCardElevated
import com.example.ui.theme.VaultDarkSurface
import com.example.ui.theme.VaultEmeraldGlow
import com.example.ui.theme.VaultEmeraldPrimary
import com.example.ui.theme.VaultErrorRed
import com.example.ui.theme.VaultTextPrimary
import com.example.ui.theme.VaultTextSecondary
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMediaPickerSheet(
    language: String,
    onDismiss: () -> Unit,
    onUrisSelected: (List<Uri>) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            onUrisSelected(uris)
        }
        onDismiss()
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = VaultDarkSurface,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .clip(CircleShape)
                    .background(VaultBorder)
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 36.dp)
                .testTag("add_media_sheet")
        ) {
            Text(
                text = Localization.getString("add_media_sheet_title", language),
                color = VaultTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = Localization.getString("add_media_sheet_sub", language),
                color = VaultTextSecondary,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            AddMediaOptionItem(
                title = Localization.getString("pick_photos_and_videos", language),
                subtitle = "JPG, PNG, MP4, MOV, MKV",
                icon = Icons.Default.PermMedia,
                accentColor = VaultEmeraldPrimary,
                testTag = "option_pick_both",
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    )
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            AddMediaOptionItem(
                title = Localization.getString("pick_photos", language),
                subtitle = "JPG, PNG, WEBP, HEIC",
                icon = Icons.Default.PhotoLibrary,
                accentColor = VaultCyanAccent,
                testTag = "option_pick_photos",
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            AddMediaOptionItem(
                title = Localization.getString("pick_videos", language),
                subtitle = "MP4, MOV, MKV",
                icon = Icons.Default.VideoLibrary,
                accentColor = VaultEmeraldGlow,
                testTag = "option_pick_videos",
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                }
            )
        }
    }
}

@Composable
private fun AddMediaOptionItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(VaultDarkCard)
            .border(1.dp, VaultBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(16.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(accentColor.copy(alpha = 0.15f))
                .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(24.dp)
            )
        }

        Column {
            Text(
                text = title,
                color = VaultTextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = VaultTextSecondary,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun ImportProgressDialog(
    current: Int,
    total: Int,
    currentBytes: Long = 0L,
    totalBytes: Long = 0L,
    language: String
) {
    AlertDialog(
        onDismissRequest = { /* Cannot cancel ongoing encryption */ },
        containerColor = VaultDarkCard,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = VaultEmeraldGlow,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = Localization.getString("encrypting_progress", language),
                    color = VaultTextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                val progress = if (totalBytes > 0L && total > 0) {
                    val itemBase = (current - 1).coerceAtLeast(0).toFloat() / total.toFloat()
                    val itemFraction = (currentBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) / total.toFloat()
                    (itemBase + itemFraction).coerceIn(0f, 1f)
                } else if (total > 0) {
                    current.toFloat() / total.toFloat()
                } else {
                    0f
                }

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                    color = VaultEmeraldPrimary,
                    trackColor = VaultBorder,
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "$current / $total items",
                        color = VaultTextSecondary,
                        fontSize = 13.sp
                    )
                    if (totalBytes > 0L) {
                        val mbCurrent = currentBytes / (1024f * 1024f)
                        val mbTotal = totalBytes / (1024f * 1024f)
                        Text(
                            text = String.format(java.util.Locale.US, "%.1f / %.1f MB", mbCurrent, mbTotal),
                            color = VaultEmeraldGlow,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
fun PostImportDeleteOriginalDialog(
    count: Int,
    language: String,
    onKeepOriginal: () -> Unit,
    onDeleteOriginal: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onKeepOriginal,
        containerColor = VaultDarkCard,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = null,
                    tint = VaultCyanAccent,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = Localization.getString("delete_original_title", language),
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Text(
                text = Localization.getString("delete_original_desc", language),
                color = VaultTextSecondary,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        },
        confirmButton = {
            Button(
                onClick = onDeleteOriginal,
                colors = ButtonDefaults.buttonColors(containerColor = VaultDarkCardElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, VaultErrorRed.copy(alpha = 0.6f))
            ) {
                Text(
                    text = Localization.getString("delete_original", language),
                    color = VaultErrorRed,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        dismissButton = {
            Button(
                onClick = onKeepOriginal,
                colors = ButtonDefaults.buttonColors(containerColor = VaultEmeraldPrimary)
            ) {
                Text(
                    text = Localization.getString("keep_original", language),
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    )
}
