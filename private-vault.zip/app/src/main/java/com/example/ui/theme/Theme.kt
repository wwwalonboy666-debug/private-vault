package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = VaultEmeraldPrimary,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF064E3B),
    onPrimaryContainer = VaultEmeraldGlow,
    secondary = VaultCyanAccent,
    onSecondary = Color.Black,
    tertiary = VaultGoldAccent,
    onTertiary = Color.Black,
    background = VaultDarkCanvas,
    onBackground = VaultTextPrimary,
    surface = VaultDarkSurface,
    onSurface = VaultTextPrimary,
    surfaceVariant = VaultDarkCard,
    onSurfaceVariant = VaultTextSecondary,
    outline = VaultBorder,
    error = VaultErrorRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF059669),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1FAE5),
    onPrimaryContainer = Color(0xFF064E3B),
    secondary = Color(0xFF0891B2),
    onSecondary = Color.White,
    tertiary = VaultGoldAccent,
    onTertiary = Color.Black,
    background = VaultLightCanvas,
    onBackground = VaultLightTextPrimary,
    surface = VaultLightSurface,
    onSurface = VaultLightTextPrimary,
    surfaceVariant = VaultLightCard,
    onSurfaceVariant = VaultLightTextSecondary,
    outline = VaultLightBorder,
    error = VaultErrorRed,
    onError = Color.White
)

@Composable
fun PrivateVaultTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
