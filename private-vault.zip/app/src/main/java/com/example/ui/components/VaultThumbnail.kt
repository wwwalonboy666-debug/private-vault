package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.data.VaultRepository
import com.example.data.model.VaultMediaEntity
import com.example.security.CryptoManager
import com.example.ui.theme.VaultDarkCardElevated
import com.example.ui.theme.VaultEmeraldGlow
import com.example.ui.theme.VaultTextMuted
import com.example.util.ThumbnailCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun VaultThumbnail(
    media: VaultMediaEntity,
    repository: VaultRepository,
    modifier: Modifier = Modifier
) {
    val initialCached = remember(media.id) { ThumbnailCache.get(media.id) }
    var bitmap by remember(media.id) { mutableStateOf(initialCached) }
    var isLoading by remember(media.id) { mutableStateOf(initialCached == null) }

    LaunchedEffect(media.id) {
        if (initialCached != null) {
            bitmap = initialCached
            isLoading = false
            return@LaunchedEffect
        }
        isLoading = true
        val loaded = withContext(Dispatchers.IO) {
            val thumbFile = repository.getThumbnailFile(media)
            if (thumbFile != null && thumbFile.exists()) {
                CryptoManager.decryptImageToBitmap(thumbFile, sampleSize = 1)
            } else {
                val encFile = repository.getEncryptedFile(media)
                if (encFile.exists() && media.mediaType == "PHOTO") {
                    CryptoManager.decryptImageToBitmap(encFile, sampleSize = 4)
                } else null
            }
        }
        if (loaded != null) {
            ThumbnailCache.put(media.id, loaded)
        }
        bitmap = loaded
        isLoading = false
    }

    Box(
        modifier = modifier.background(VaultDarkCardElevated),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = media.originalFileName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = VaultEmeraldGlow,
                strokeWidth = 2.dp
            )
        } else {
            Icon(
                imageVector = Icons.Default.BrokenImage,
                contentDescription = null,
                tint = VaultTextMuted,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}
