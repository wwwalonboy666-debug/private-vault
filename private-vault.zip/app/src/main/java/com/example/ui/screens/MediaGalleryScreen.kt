package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VaultRepository
import com.example.data.model.VaultMediaEntity
import com.example.ui.components.VaultThumbnail
import com.example.ui.theme.VaultBorder
import com.example.ui.theme.VaultCyanAccent
import com.example.ui.theme.VaultDarkCanvas
import com.example.ui.theme.VaultDarkCard
import com.example.ui.theme.VaultDarkCardElevated
import com.example.ui.theme.VaultDarkSurface
import com.example.ui.theme.VaultEmeraldGlow
import com.example.ui.theme.VaultEmeraldPrimary
import com.example.ui.theme.VaultErrorRed
import com.example.ui.theme.VaultTextMuted
import com.example.ui.theme.VaultTextPrimary
import com.example.ui.theme.VaultTextSecondary
import com.example.util.Localization

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MediaGalleryScreen(
    mediaType: String, // "PHOTO" or "VIDEO"
    mediaList: List<VaultMediaEntity>,
    repository: VaultRepository,
    language: String,
    onBack: () -> Unit,
    onOpenMedia: (VaultMediaEntity) -> Unit,
    onAddMedia: () -> Unit,
    onRestoreBatch: (List<VaultMediaEntity>) -> Unit,
    onDeleteBatch: (List<VaultMediaEntity>) -> Unit
) {
    val isVideo = mediaType == "VIDEO"
    val selectedIds = remember { mutableStateListOf<Long>() }
    val isMultiSelectMode = selectedIds.isNotEmpty()

    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }

    fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return String.format("%02d:%02d", min, sec)
    }

    Scaffold(
        containerColor = VaultDarkCanvas,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VaultDarkSurface)
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            if (isMultiSelectMode) {
                                selectedIds.clear()
                            } else {
                                onBack()
                            }
                        },
                        modifier = Modifier.testTag("gallery_back_btn")
                    ) {
                        Icon(
                            imageVector = if (isMultiSelectMode) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = VaultTextPrimary
                        )
                    }

                    Text(
                        text = if (isMultiSelectMode) {
                            "${selectedIds.size} " + Localization.getString("selected_count", language)
                        } else {
                            if (isVideo) Localization.getString("videos_card_title", language)
                            else Localization.getString("photos_card_title", language)
                        },
                        color = VaultTextPrimary,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }

                if (isMultiSelectMode) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                if (selectedIds.size == mediaList.size) {
                                    selectedIds.clear()
                                } else {
                                    selectedIds.clear()
                                    selectedIds.addAll(mediaList.map { it.id })
                                }
                            },
                            modifier = Modifier.testTag("select_all_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SelectAll,
                                contentDescription = Localization.getString("select_all", language),
                                tint = VaultEmeraldGlow
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            if (isMultiSelectMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(VaultDarkSurface)
                        .border(1.dp, VaultBorder)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { showRestoreConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = VaultDarkCardElevated),
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                            .testTag("batch_restore_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = null,
                                tint = VaultEmeraldGlow,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = Localization.getString("restore_selected", language),
                                color = VaultEmeraldGlow,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Button(
                        onClick = { showDeleteConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = VaultDarkCardElevated),
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 8.dp)
                            .testTag("batch_delete_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                tint = VaultErrorRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = Localization.getString("delete_selected", language),
                                color = VaultErrorRed,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (!isMultiSelectMode) {
                FloatingActionButton(
                    onClick = onAddMedia,
                    containerColor = VaultEmeraldPrimary,
                    contentColor = Color.Black,
                    shape = CircleShape,
                    modifier = Modifier.testTag("gallery_fab_add")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (mediaList.isEmpty()) {
                // Empty state
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(VaultDarkCard)
                            .border(1.dp, VaultBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isVideo) Icons.Default.VideoLibrary else Icons.Default.PhotoLibrary,
                            contentDescription = null,
                            tint = VaultTextMuted,
                            modifier = Modifier.size(42.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = if (isVideo) Localization.getString("empty_videos_title", language)
                        else Localization.getString("empty_photos_title", language),
                        color = VaultTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isVideo) Localization.getString("empty_videos_desc", language)
                        else Localization.getString("empty_photos_desc", language),
                        color = VaultTextSecondary,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onAddMedia,
                        colors = ButtonDefaults.buttonColors(containerColor = VaultEmeraldPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.testTag("empty_import_btn")
                    ) {
                        Text(
                            text = if (isVideo) Localization.getString("import_video_action", language)
                            else Localization.getString("import_photo_action", language),
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(4.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(mediaList, key = { it.id }) { item ->
                        val isSelected = selectedIds.contains(item.id)

                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    width = if (isSelected) 2.5.dp else 0.5.dp,
                                    color = if (isSelected) VaultEmeraldGlow else VaultBorder,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .combinedClickable(
                                    onClick = {
                                        if (isMultiSelectMode) {
                                            if (isSelected) selectedIds.remove(item.id)
                                            else selectedIds.add(item.id)
                                        } else {
                                            onOpenMedia(item)
                                        }
                                    },
                                    onLongClick = {
                                        if (!isMultiSelectMode) {
                                            selectedIds.add(item.id)
                                        }
                                    }
                                )
                                .testTag("media_item_${item.id}")
                        ) {
                            VaultThumbnail(
                                media = item,
                                repository = repository,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Video Duration & Play icon badge
                            if (isVideo) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(4.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color.Black.copy(alpha = 0.7f))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        if (item.durationMs > 0) {
                                            Text(
                                                text = formatDuration(item.durationMs),
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }
                            }

                            // Selection Indicator
                            if (isMultiSelectMode) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) VaultEmeraldPrimary else Color.Black.copy(alpha = 0.5f)
                                        )
                                        .border(
                                            1.5.dp,
                                            if (isSelected) VaultEmeraldGlow else Color.White,
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Restore Confirm Dialog
    if (showRestoreConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirmDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Text(
                    text = Localization.getString("restore_title", language),
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = Localization.getString("restore_desc", language),
                    color = VaultTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val selectedMedia = mediaList.filter { selectedIds.contains(it.id) }
                        selectedIds.clear()
                        showRestoreConfirmDialog = false
                        onRestoreBatch(selectedMedia)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultEmeraldPrimary)
                ) {
                    Text(Localization.getString("confirm_restore", language), color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreConfirmDialog = false }) {
                    Text(Localization.getString("cancel", language), color = VaultTextSecondary)
                }
            }
        )
    }

    // Delete Confirm Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Text(
                    text = Localization.getString("delete_title", language),
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = Localization.getString("delete_desc", language),
                    color = VaultTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val selectedMedia = mediaList.filter { selectedIds.contains(it.id) }
                        selectedIds.clear()
                        showDeleteConfirmDialog = false
                        onDeleteBatch(selectedMedia)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultErrorRed)
                ) {
                    Text(Localization.getString("confirm_delete", language), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text(Localization.getString("cancel", language), color = VaultTextSecondary)
                }
            }
        )
    }
}
