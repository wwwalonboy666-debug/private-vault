package com.example.ui.screens

import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.VaultRepository
import com.example.data.model.VaultMediaEntity
import com.example.security.CryptoManager
import com.example.ui.theme.VaultDarkCanvas
import com.example.ui.theme.VaultDarkCard
import com.example.ui.theme.VaultEmeraldGlow
import com.example.ui.theme.VaultEmeraldPrimary
import com.example.ui.theme.VaultErrorRed
import com.example.ui.theme.VaultTextPrimary
import com.example.ui.theme.VaultTextSecondary
import com.example.util.Localization
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VideoPlayerScreen(
    media: VaultMediaEntity,
    repository: VaultRepository,
    language: String,
    onBack: () -> Unit,
    onRestore: (VaultMediaEntity) -> Unit,
    onDelete: (VaultMediaEntity) -> Unit
) {
    val context = LocalContext.current
    var tempVideoFile by remember { mutableStateOf<File?>(null) }
    var isDecrypting by remember { mutableStateOf(true) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }

    LaunchedEffect(media.id) {
        isDecrypting = true
        val tempFile = withContext(Dispatchers.IO) {
            val encFile = repository.getEncryptedFile(media)
            if (encFile.exists()) {
                val ext = when {
                    media.originalFileName.endsWith(".mp4", true) -> ".mp4"
                    media.originalFileName.endsWith(".mov", true) -> ".mov"
                    media.originalFileName.endsWith(".mkv", true) -> ".mkv"
                    else -> ".mp4"
                }
                CryptoManager.decryptToTempFile(context, encFile, "play_${media.id}", ext)
            } else null
        }
        tempVideoFile = tempFile
        isDecrypting = false
    }

    // Always delete decrypted temporary file when exiting the screen
    DisposableEffect(Unit) {
        onDispose {
            tempVideoFile?.delete()
        }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 KB"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, 4)
        return DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
    }

    val formattedDate = remember(media.createdAt) {
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        sdf.format(Date(media.createdAt))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(VaultDarkCanvas)
            .testTag("video_player_screen")
    ) {
        if (isDecrypting) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(
                    color = VaultEmeraldGlow,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(44.dp)
                )
                Spacer(modifier = Modifier.size(16.dp))
                Text(
                    text = "Decrypting video...",
                    color = VaultTextSecondary,
                    fontSize = 14.sp
                )
            }
        } else if (tempVideoFile != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    VideoView(ctx).apply {
                        val controller = MediaController(ctx)
                        controller.setAnchorView(this)
                        setMediaController(controller)
                        setVideoPath(tempVideoFile!!.absolutePath)
                        setOnPreparedListener { mp ->
                            mp.isLooping = false
                            start()
                        }
                    }
                }
            )
        } else {
            Text(
                text = "Failed to load video",
                color = VaultErrorRed,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // Top Navigation Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Color.Black.copy(alpha = 0.65f))
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("player_back_btn")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Text(
                    text = media.originalFileName,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }

            IconButton(onClick = { showInfoDialog = true }, modifier = Modifier.testTag("player_info_btn")) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Info",
                    tint = Color.White
                )
            }
        }

        // Bottom Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color.Black.copy(alpha = 0.75f))
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { showRestoreDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = VaultDarkCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
                    .testTag("player_restore_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = null,
                    tint = VaultEmeraldGlow,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = Localization.getString("restore_selected", language),
                    color = VaultEmeraldGlow,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Button(
                onClick = { showDeleteDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = VaultDarkCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp)
                    .testTag("player_delete_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = null,
                    tint = VaultErrorRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = Localization.getString("delete_selected", language),
                    color = VaultErrorRed,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }

    // Info Dialog
    if (showInfoDialog) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Text(
                    text = "Video Details",
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Name: ${media.originalFileName}", color = VaultTextSecondary, fontSize = 13.sp)
                    Text(text = "Size: ${formatBytes(media.fileSize)}", color = VaultTextSecondary, fontSize = 13.sp)
                    Text(text = "Type: ${media.mimeType}", color = VaultTextSecondary, fontSize = 13.sp)
                    Text(text = "Added: $formattedDate", color = VaultTextSecondary, fontSize = 13.sp)
                    Text(text = "Encryption: AES-256-GCM (Hardware Backed)", color = VaultEmeraldGlow, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showInfoDialog = false }) {
                    Text(Localization.getString("close", language), color = VaultEmeraldPrimary)
                }
            }
        )
    }

    // Restore Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Text(
                    text = Localization.getString("restore_title", language),
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = Localization.getString("restore_desc", language),
                    color = VaultTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRestoreDialog = false
                        onRestore(media)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultEmeraldPrimary)
                ) {
                    Text(Localization.getString("confirm_restore", language), color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text(Localization.getString("cancel", language), color = VaultTextSecondary)
                }
            }
        )
    }

    // Delete Dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Text(
                    text = Localization.getString("delete_title", language),
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = Localization.getString("delete_desc", language),
                    color = VaultTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteDialog = false
                        onDelete(media)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultErrorRed)
                ) {
                    Text(Localization.getString("confirm_delete", language), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(Localization.getString("cancel", language), color = VaultTextSecondary)
                }
            }
        )
    }
}
