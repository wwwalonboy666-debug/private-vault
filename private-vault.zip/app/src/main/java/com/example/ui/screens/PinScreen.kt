package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.example.R
import com.example.security.SecurityManager
import com.example.ui.theme.VaultBorder
import com.example.ui.theme.VaultCyanAccent
import com.example.ui.theme.VaultDarkCanvas
import com.example.ui.theme.VaultDarkCard
import com.example.ui.theme.VaultEmeraldGlow
import com.example.ui.theme.VaultEmeraldPrimary
import com.example.ui.theme.VaultErrorRed
import com.example.ui.theme.VaultTextMuted
import com.example.ui.theme.VaultTextPrimary
import com.example.ui.theme.VaultTextSecondary
import com.example.util.Localization
import com.example.util.SoundManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class PinMode {
    SETUP_CREATE,
    SETUP_CONFIRM,
    UNLOCK,
    CHANGE_OLD,
    CHANGE_NEW,
    CHANGE_CONFIRM
}

@Composable
fun PinScreen(
    isFirstTimeSetup: Boolean,
    isSoundEnabled: Boolean,
    isBiometricEnabled: Boolean,
    language: String,
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentMode by remember(isFirstTimeSetup) {
        mutableStateOf(if (isFirstTimeSetup) PinMode.SETUP_CREATE else PinMode.UNLOCK)
    }

    var enteredPin by remember { mutableStateOf("") }
    var firstSetupPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var lockoutSeconds by remember { mutableIntStateOf(0) }

    // Shake animation offset
    val shakeOffset = remember { Animatable(0f) }

    // Check lockout on enter and run countdown
    LaunchedEffect(Unit) {
        val status = SecurityManager.checkLockoutStatus(context)
        if (status.isLockedOut) {
            lockoutSeconds = status.remainingSeconds
        }
    }

    LaunchedEffect(lockoutSeconds) {
        if (lockoutSeconds > 0) {
            delay(1000L)
            lockoutSeconds -= 1
        }
    }

    fun triggerShake() {
        coroutineScope.launch {
            shakeOffset.animateElevationKeyframes()
        }
    }

    // Auto-prompt biometric on unlock if enabled and available
    LaunchedEffect(currentMode) {
        if (currentMode == PinMode.UNLOCK && isBiometricEnabled && lockoutSeconds == 0) {
            if (SecurityManager.canUseBiometrics(context)) {
                val activity = context as? FragmentActivity
                activity?.let {
                    SecurityManager.promptBiometric(
                        activity = it,
                        title = Localization.getString("biometric_prompt_title", language),
                        subtitle = Localization.getString("biometric_prompt_sub", language),
                        negativeButtonText = Localization.getString("biometric_cancel", language),
                        onSuccess = {
                            onSuccess()
                        },
                        onError = { /* fallback to PIN */ }
                    )
                }
            }
        }
    }

    fun onDigitPress(digit: String) {
        if (lockoutSeconds > 0) return
        if (enteredPin.length < 6) {
            SoundManager.playKeypadClick(isSoundEnabled)
            val newPin = enteredPin + digit
            enteredPin = newPin
            errorMessage = null

            if (newPin.length == 6) {
                when (currentMode) {
                    PinMode.SETUP_CREATE -> {
                        firstSetupPin = newPin
                        enteredPin = ""
                        currentMode = PinMode.SETUP_CONFIRM
                    }
                    PinMode.SETUP_CONFIRM -> {
                        if (newPin == firstSetupPin) {
                            SecurityManager.setPin(context, newPin)
                            onSuccess()
                        } else {
                            errorMessage = Localization.getString("pin_mismatch", language)
                            triggerShake()
                            enteredPin = ""
                            firstSetupPin = ""
                            currentMode = PinMode.SETUP_CREATE
                        }
                    }
                    PinMode.UNLOCK -> {
                        when (val result = SecurityManager.verifyPin(context, newPin)) {
                            is SecurityManager.PinVerifyResult.Success -> {
                                onSuccess()
                            }
                            is SecurityManager.PinVerifyResult.Incorrect -> {
                                errorMessage = Localization.getString("pin_incorrect", language)
                                triggerShake()
                                enteredPin = ""
                            }
                            is SecurityManager.PinVerifyResult.LockedOut -> {
                                lockoutSeconds = result.remainingSeconds
                                errorMessage = Localization.getString("locked_out", language) + "${result.remainingSeconds}s"
                                triggerShake()
                                enteredPin = ""
                            }
                        }
                    }
                    else -> {}
                }
            }
        }
    }

    fun onBackspacePress() {
        if (enteredPin.isNotEmpty()) {
            SoundManager.playKeypadClick(isSoundEnabled)
            enteredPin = enteredPin.dropLast(1)
            errorMessage = null
        }
    }

    fun onBiometricTap() {
        if (lockoutSeconds > 0) return
        val activity = context as? FragmentActivity
        activity?.let {
            SecurityManager.promptBiometric(
                activity = it,
                title = Localization.getString("biometric_prompt_title", language),
                subtitle = Localization.getString("biometric_prompt_sub", language),
                negativeButtonText = Localization.getString("biometric_cancel", language),
                onSuccess = onSuccess,
                onError = { /* stay on PIN screen */ }
            )
        }
    }

    val titleText = when (currentMode) {
        PinMode.SETUP_CREATE -> Localization.getString("create_pin_title", language)
        PinMode.SETUP_CONFIRM -> Localization.getString("confirm_pin_title", language)
        PinMode.UNLOCK -> Localization.getString("welcome_back", language)
        else -> ""
    }

    val subtitleText = when (currentMode) {
        PinMode.SETUP_CREATE -> Localization.getString("create_pin_subtitle", language)
        PinMode.SETUP_CONFIRM -> Localization.getString("confirm_pin_subtitle", language)
        PinMode.UNLOCK -> Localization.getString("enter_pin", language)
        else -> ""
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF131D31),
                        Color(0xFF0A0F1D),
                        VaultDarkCanvas
                    ),
                    center = Offset.Unspecified,
                    radius = 1200f
                )
            )
            .testTag("pin_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Header & Status
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
            ) {
                // Shield Logo
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .shadow(12.dp, CircleShape, ambientColor = VaultEmeraldGlow)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                listOf(VaultEmeraldPrimary.copy(alpha = 0.2f), Color(0xFF131F33))
                            )
                        )
                        .border(1.dp, VaultBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_vault_logo),
                        contentDescription = "Vault Icon",
                        modifier = Modifier.size(60.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = titleText,
                    color = VaultTextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = subtitleText,
                    color = VaultTextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                // PIN Dots with shake effect
                Row(
                    modifier = Modifier
                        .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until 6) {
                        val isFilled = i < enteredPin.length
                        val dotScale = if (isFilled) 1.25f else 1.0f
                        Box(
                            modifier = Modifier
                                .size(15.dp)
                                .scale(dotScale)
                                .clip(CircleShape)
                                .background(
                                    if (isFilled) {
                                        VaultEmeraldPrimary
                                    } else {
                                        Color(0xFF1E293B)
                                    }
                                )
                                .border(
                                    width = if (isFilled) 0.dp else 1.5.dp,
                                    color = if (isFilled) VaultEmeraldGlow else VaultBorder,
                                    shape = CircleShape
                                )
                        )
                    }
                }

                // Error or Lockout message
                if (lockoutSeconds > 0) {
                    Text(
                        text = Localization.getString("locked_out", language) + "${lockoutSeconds}s",
                        color = VaultErrorRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                } else if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = VaultErrorRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                } else {
                    Spacer(modifier = Modifier.height(18.dp))
                }
            }

            // Numeric Keypad
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val keypadRows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("BIO", "0", "BACK")
                )

                for (row in keypadRows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (key in row) {
                            when (key) {
                                "BIO" -> {
                                    if (currentMode == PinMode.UNLOCK && isBiometricEnabled && SecurityManager.canUseBiometrics(context)) {
                                        KeypadActionButton(
                                            icon = {
                                                Icon(
                                                    imageVector = Icons.Default.Fingerprint,
                                                    contentDescription = "Biometric Unlock",
                                                    tint = VaultEmeraldGlow,
                                                    modifier = Modifier.size(28.dp)
                                                )
                                            },
                                            testTag = "biometric_btn",
                                            onClick = { onBiometricTap() }
                                        )
                                    } else {
                                        Spacer(modifier = Modifier.size(62.dp))
                                    }
                                }
                                "BACK" -> {
                                    KeypadActionButton(
                                        icon = {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                                contentDescription = "Backspace",
                                                tint = VaultTextSecondary,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        },
                                        testTag = "backspace_btn",
                                        onClick = { onBackspacePress() }
                                    )
                                }
                                else -> {
                                    KeypadNumberButton(
                                        number = key,
                                        enabled = lockoutSeconds == 0,
                                        onClick = { onDigitPress(key) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun Animatable<Float, *>.animateElevationKeyframes() {
    animateTo(
        targetValue = 0f,
        animationSpec = keyframes {
            durationMillis = 350
            0f at 0
            (-14f) at 50
            14f at 100
            (-12f) at 150
            12f at 200
            (-8f) at 250
            8f at 300
            0f at 350
        }
    )
}

@Composable
private fun KeypadNumberButton(
    number: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(62.dp)
            .clip(CircleShape)
            .background(Color(0xFF131C2D))
            .border(1.dp, VaultBorder.copy(alpha = 0.6f), CircleShape)
            .clickable(
                enabled = enabled,
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = VaultEmeraldGlow),
                onClick = onClick
            )
            .testTag("keypad_$number"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = number,
            color = if (enabled) VaultTextPrimary else VaultTextMuted,
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun KeypadActionButton(
    icon: @Composable () -> Unit,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(62.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = VaultEmeraldGlow),
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        icon()
    }
}
