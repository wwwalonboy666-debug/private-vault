package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Dark Theme Palette
val VaultDarkCanvas = Color(0xFF07090E)
val VaultDarkSurface = Color(0xFF0F172A)
val VaultDarkCard = Color(0xFF151F32)
val VaultDarkCardElevated = Color(0xFF1C2740)
val VaultBorder = Color(0xFF263550)

// Accent Colors
val VaultEmeraldPrimary = Color(0xFF10B981)
val VaultEmeraldGlow = Color(0xFF34D399)
val VaultCyanAccent = Color(0xFF06B6D4)
val VaultGoldAccent = Color(0xFFF59E0B)
val VaultErrorRed = Color(0xFFEF4444)

// Text Colors
val VaultTextPrimary = Color(0xFFF8FAFC)
val VaultTextSecondary = Color(0xFF94A3B8)
val VaultTextMuted = Color(0xFF64748B)

// Light Theme Palette (if user toggles to light mode)
val VaultLightCanvas = Color(0xFFF8FAFC)
val VaultLightSurface = Color(0xFFFFFFFF)
val VaultLightCard = Color(0xFFF1F5F9)
val VaultLightBorder = Color(0xFFCBD5E1)
val VaultLightTextPrimary = Color(0xFF0F172A)
val VaultLightTextSecondary = Color(0xFF475569)
