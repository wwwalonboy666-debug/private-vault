package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SettingsRepository
import com.example.data.VaultDatabase
import com.example.data.VaultRepository
import com.example.data.model.VaultMediaEntity
import com.example.security.SecurityManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class VaultScreen {
    SPLASH,
    PIN_SETUP,
    LOCK_SCREEN,
    HOME,
    GALLERY_PHOTOS,
    GALLERY_VIDEOS,
    PHOTO_VIEWER,
    VIDEO_PLAYER,
    SETTINGS
}

class VaultViewModel(application: Application) : AndroidViewModel(application) {
    val database = VaultDatabase.getDatabase(application)
    val repository = VaultRepository(application, database.vaultMediaDao())
    val settingsRepository = SettingsRepository(application)

    private val _currentScreen = MutableStateFlow(VaultScreen.SPLASH)
    val currentScreen: StateFlow<VaultScreen> = _currentScreen.asStateFlow()

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val photos: StateFlow<List<VaultMediaEntity>> = repository.allPhotos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val videos: StateFlow<List<VaultMediaEntity>> = repository.allVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val photosCount: StateFlow<Int> = repository.photosCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val videosCount: StateFlow<Int> = repository.videosCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalBytes: StateFlow<Long> = repository.totalBytes
        .map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // Import progress: current, total
    private val _importProgress = MutableStateFlow<Pair<Int, Int>?>(null)
    val importProgress: StateFlow<Pair<Int, Int>?> = _importProgress.asStateFlow()

    // Holds original URIs after successful import to ask user whether to delete originals
    private val _pendingDeleteOriginalUris = MutableStateFlow<List<Uri>?>(null)
    val pendingDeleteOriginalUris: StateFlow<List<Uri>?> = _pendingDeleteOriginalUris.asStateFlow()

    // Viewer states
    private val _activePhoto = MutableStateFlow<VaultMediaEntity?>(null)
    val activePhoto: StateFlow<VaultMediaEntity?> = _activePhoto.asStateFlow()

    private val _activeVideo = MutableStateFlow<VaultMediaEntity?>(null)
    val activeVideo: StateFlow<VaultMediaEntity?> = _activeVideo.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    fun onSplashFinished() {
        val hasPin = SecurityManager.isPinSet(getApplication())
        if (hasPin) {
            _currentScreen.value = VaultScreen.LOCK_SCREEN
        } else {
            _currentScreen.value = VaultScreen.PIN_SETUP
        }
    }

    fun onPinSuccess() {
        _isUnlocked.value = true
        SecurityManager.updateLastActive(getApplication())
        _currentScreen.value = VaultScreen.HOME
    }

    fun lockNow() {
        _isUnlocked.value = false
        _currentScreen.value = VaultScreen.LOCK_SCREEN
    }

    fun navigateTo(screen: VaultScreen) {
        _currentScreen.value = screen
    }

    fun openPhotoViewer(media: VaultMediaEntity) {
        _activePhoto.value = media
        _currentScreen.value = VaultScreen.PHOTO_VIEWER
    }

    fun openVideoPlayer(media: VaultMediaEntity) {
        _activeVideo.value = media
        _currentScreen.value = VaultScreen.VIDEO_PLAYER
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _importProgress.value = Pair(0, uris.size)
            val successfulUris = mutableListOf<Uri>()

            for ((index, uri) in uris.withIndex()) {
                _importProgress.value = Pair(index + 1, uris.size)
                when (val res = repository.importMedia(uri)) {
                    is VaultRepository.ImportResult.Success -> {
                        successfulUris.add(res.originalUri)
                    }
                    is VaultRepository.ImportResult.Failure -> {
                        // Keep track of errors
                    }
                }
            }

            _importProgress.value = null

            if (successfulUris.isNotEmpty()) {
                _pendingDeleteOriginalUris.value = successfulUris
            }
        }
    }

    fun dismissDeleteOriginalsPrompt() {
        _pendingDeleteOriginalUris.value = null
    }

    fun confirmDeleteOriginals(context: Context) {
        val uris = _pendingDeleteOriginalUris.value ?: return
        viewModelScope.launch {
            for (uri in uris) {
                try {
                    context.contentResolver.delete(uri, null, null)
                } catch (e: Exception) {
                    // On modern Android (Q+), deleting media owned by other apps may require RecoverableSecurityException
                    e.printStackTrace()
                }
            }
            _pendingDeleteOriginalUris.value = null
        }
    }

    fun restoreSingleMedia(media: VaultMediaEntity) {
        viewModelScope.launch {
            val success = repository.restoreMedia(media)
            if (success) {
                _userMessage.value = "Restored to gallery"
                if (_currentScreen.value == VaultScreen.PHOTO_VIEWER) {
                    _currentScreen.value = VaultScreen.GALLERY_PHOTOS
                } else if (_currentScreen.value == VaultScreen.VIDEO_PLAYER) {
                    _currentScreen.value = VaultScreen.GALLERY_VIDEOS
                }
            }
        }
    }

    fun deleteSingleMedia(media: VaultMediaEntity) {
        viewModelScope.launch {
            val success = repository.deleteMedia(media)
            if (success) {
                _userMessage.value = "Deleted from vault"
                if (_currentScreen.value == VaultScreen.PHOTO_VIEWER) {
                    _currentScreen.value = VaultScreen.GALLERY_PHOTOS
                } else if (_currentScreen.value == VaultScreen.VIDEO_PLAYER) {
                    _currentScreen.value = VaultScreen.GALLERY_VIDEOS
                }
            }
        }
    }

    fun restoreBatch(list: List<VaultMediaEntity>) {
        viewModelScope.launch {
            var restoredCount = 0
            list.forEach { media ->
                if (repository.restoreMedia(media)) restoredCount++
            }
            _userMessage.value = "$restoredCount items restored to gallery"
        }
    }

    fun deleteBatch(list: List<VaultMediaEntity>) {
        viewModelScope.launch {
            val deletedCount = repository.deleteBatch(list)
            _userMessage.value = "$deletedCount items deleted from vault"
        }
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun checkAutoLock() {
        if (_isUnlocked.value && _currentScreen.value != VaultScreen.SPLASH) {
            val timeout = settingsRepository.autoLockMs.value
            if (SecurityManager.shouldAutoLock(getApplication(), timeout)) {
                lockNow()
            }
        }
    }

    fun onUserActive() {
        if (_isUnlocked.value) {
            SecurityManager.updateLastActive(getApplication())
        }
    }
}
