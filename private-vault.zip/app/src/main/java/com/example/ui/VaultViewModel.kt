package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.result.IntentSenderRequest
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SettingsRepository
import com.example.data.VaultDatabase
import com.example.data.VaultRepository
import com.example.data.model.VaultMediaEntity
import com.example.security.SecurityManager
import com.example.util.DeletionResult
import com.example.util.MediaStoreDeletionHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class VaultScreen {
    SPLASH,
    PIN_SETUP,
    LOCK_SCREEN,
    HOME,
    GALLERY_PHOTOS,
    GALLERY_VIDEOS,
    PHOTO_VIEWER,
    VIDEO_PLAYER,
    SETTINGS
}

data class ImportProgressState(
    val currentIndex: Int,
    val totalCount: Int,
    val currentBytes: Long = 0L,
    val totalBytes: Long = 0L
)

class VaultViewModel(application: Application) : AndroidViewModel(application) {
    val database = VaultDatabase.getDatabase(application)
    val repository = VaultRepository(application, database.vaultMediaDao())
    val settingsRepository = SettingsRepository(application)

    private val _currentScreen = MutableStateFlow(VaultScreen.SPLASH)
    val currentScreen: StateFlow<VaultScreen> = _currentScreen.asStateFlow()

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val photos: StateFlow<List<VaultMediaEntity>> = repository.allPhotos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val videos: StateFlow<List<VaultMediaEntity>> = repository.allVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val photosCount: StateFlow<Int> = repository.photosCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val videosCount: StateFlow<Int> = repository.videosCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalBytes: StateFlow<Long> = repository.totalBytes
        .map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // Detailed import progress
    private val _importProgress = MutableStateFlow<ImportProgressState?>(null)
    val importProgress: StateFlow<ImportProgressState?> = _importProgress.asStateFlow()

    // Holds original URIs after successful import to ask user whether to delete originals
    private val _pendingDeleteOriginalUris = MutableStateFlow<List<Uri>?>(null)
    val pendingDeleteOriginalUris: StateFlow<List<Uri>?> = _pendingDeleteOriginalUris.asStateFlow()

    private var pendingConsentUris: List<Uri>? = null

    // Viewer states
    private val _activePhoto = MutableStateFlow<VaultMediaEntity?>(null)
    val activePhoto: StateFlow<VaultMediaEntity?> = _activePhoto.asStateFlow()

    private val _activeVideo = MutableStateFlow<VaultMediaEntity?>(null)
    val activeVideo: StateFlow<VaultMediaEntity?> = _activeVideo.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    fun onSplashFinished() {
        val hasPin = SecurityManager.isPinSet(getApplication())
        if (hasPin) {
            _currentScreen.value = VaultScreen.LOCK_SCREEN
        } else {
            _currentScreen.value = VaultScreen.PIN_SETUP
        }
    }

    fun onPinSuccess() {
        _isUnlocked.value = true
        SecurityManager.updateLastActive(getApplication())
        _currentScreen.value = VaultScreen.HOME
    }

    fun lockNow() {
        _isUnlocked.value = false
        _currentScreen.value = VaultScreen.LOCK_SCREEN
    }

    fun navigateTo(screen: VaultScreen) {
        _currentScreen.value = screen
    }

    fun openPhotoViewer(media: VaultMediaEntity) {
        _activePhoto.value = media
        _currentScreen.value = VaultScreen.PHOTO_VIEWER
    }

    fun openVideoPlayer(media: VaultMediaEntity) {
        _activeVideo.value = media
        _currentScreen.value = VaultScreen.VIDEO_PLAYER
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _importProgress.value = ImportProgressState(0, uris.size)
            val successfulUris = mutableListOf<Uri>()

            for ((index, uri) in uris.withIndex()) {
                _importProgress.value = ImportProgressState(index + 1, uris.size, 0L, 0L)
                val res = repository.importMedia(uri) { bytesRead, totalBytes ->
                    _importProgress.value = ImportProgressState(index + 1, uris.size, bytesRead, totalBytes)
                }
                when (res) {
                    is VaultRepository.ImportResult.Success -> {
                        successfulUris.add(res.originalUri)
                    }
                    is VaultRepository.ImportResult.Failure -> {
                        // Continue with others
                    }
                }
            }

            _importProgress.value = null

            if (successfulUris.isNotEmpty()) {
                _pendingDeleteOriginalUris.value = successfulUris
            }
        }
    }

    fun dismissDeleteOriginalsPrompt() {
        _pendingDeleteOriginalUris.value = null
        pendingConsentUris = null
    }

    fun confirmDeleteOriginals(
        context: Context,
        launchIntentSender: (IntentSenderRequest) -> Unit
    ) {
        val uris = _pendingDeleteOriginalUris.value ?: return
        viewModelScope.launch {
            when (val result = MediaStoreDeletionHelper.prepareDeletion(context, uris)) {
                is DeletionResult.RequiresUserConsent -> {
                    pendingConsentUris = result.uris
                    try {
                        val request = IntentSenderRequest.Builder(result.intentSender).build()
                        launchIntentSender(request)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        _userMessage.value = "Failed to launch deletion prompt: ${e.localizedMessage}"
                        _pendingDeleteOriginalUris.value = null
                    }
                }
                is DeletionResult.Completed -> {
                    val verifiedDeleted = MediaStoreDeletionHelper.verifyUrisDeleted(context, uris)
                    if (verifiedDeleted > 0) {
                        _userMessage.value = "$verifiedDeleted original item(s) deleted from device"
                    } else if (result.successCount > 0) {
                        _userMessage.value = "${result.successCount} original item(s) deleted from device"
                    } else {
                        _userMessage.value = "Original files could not be deleted"
                    }
                    _pendingDeleteOriginalUris.value = null
                }
                is DeletionResult.Error -> {
                    _userMessage.value = "Delete error: ${result.message}"
                    _pendingDeleteOriginalUris.value = null
                }
            }
        }
    }

    fun onDeleteOriginalsConsentResult(context: Context, isGranted: Boolean) {
        val uris = pendingConsentUris ?: _pendingDeleteOriginalUris.value ?: return
        pendingConsentUris = null
        _pendingDeleteOriginalUris.value = null

        if (isGranted) {
            val verifiedDeleted = MediaStoreDeletionHelper.verifyUrisDeleted(context, uris)
            if (verifiedDeleted > 0) {
                _userMessage.value = "$verifiedDeleted original item(s) deleted from device"
            } else {
                _userMessage.value = "Original files deleted from device"
            }
        } else {
            _userMessage.value = "Deletion cancelled. Originals kept on device."
        }
    }

    fun restoreSingleMedia(media: VaultMediaEntity) {
        viewModelScope.launch {
            val success = repository.restoreMedia(media)
            if (success) {
                _userMessage.value = "Restored to gallery"
                if (_currentScreen.value == VaultScreen.PHOTO_VIEWER) {
                    _currentScreen.value = VaultScreen.GALLERY_PHOTOS
                } else if (_currentScreen.value == VaultScreen.VIDEO_PLAYER) {
                    _currentScreen.value = VaultScreen.GALLERY_VIDEOS
                }
            }
        }
    }

    fun deleteSingleMedia(media: VaultMediaEntity) {
        viewModelScope.launch {
            val success = repository.deleteMedia(media)
            if (success) {
                _userMessage.value = "Deleted from vault"
                if (_currentScreen.value == VaultScreen.PHOTO_VIEWER) {
                    _currentScreen.value = VaultScreen.GALLERY_PHOTOS
                } else if (_currentScreen.value == VaultScreen.VIDEO_PLAYER) {
                    _currentScreen.value = VaultScreen.GALLERY_VIDEOS
                }
            }
        }
    }

    fun restoreBatch(list: List<VaultMediaEntity>) {
        viewModelScope.launch {
            var restoredCount = 0
            list.forEach { media ->
                if (repository.restoreMedia(media)) restoredCount++
            }
            _userMessage.value = "$restoredCount items restored to gallery"
        }
    }

    fun deleteBatch(list: List<VaultMediaEntity>) {
        viewModelScope.launch {
            val deletedCount = repository.deleteBatch(list)
            _userMessage.value = "$deletedCount items deleted from vault"
        }
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun checkAutoLock() {
        if (_isUnlocked.value && _currentScreen.value != VaultScreen.SPLASH) {
            val timeout = settingsRepository.autoLockMs.value
            if (SecurityManager.shouldAutoLock(getApplication(), timeout)) {
                lockNow()
            }
        }
    }

    fun onUserActive() {
        if (_isUnlocked.value) {
            SecurityManager.updateLastActive(getApplication())
        }
    }
}
