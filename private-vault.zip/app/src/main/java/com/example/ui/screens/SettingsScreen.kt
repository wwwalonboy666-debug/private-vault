package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SettingsRepository
import com.example.security.SecurityManager
import com.example.ui.theme.VaultBorder
import com.example.ui.theme.VaultCyanAccent
import com.example.ui.theme.VaultDarkCanvas
import com.example.ui.theme.VaultDarkCard
import com.example.ui.theme.VaultDarkSurface
import com.example.ui.theme.VaultEmeraldGlow
import com.example.ui.theme.VaultEmeraldPrimary
import com.example.ui.theme.VaultErrorRed
import com.example.ui.theme.VaultTextMuted
import com.example.ui.theme.VaultTextPrimary
import com.example.ui.theme.VaultTextSecondary
import com.example.util.Localization

@Composable
fun SettingsScreen(
    settingsRepository: SettingsRepository,
    isBiometricEnabled: Boolean,
    autoLockMs: Long,
    isSoundEnabled: Boolean,
    isDarkMode: Boolean,
    language: String,
    isScreenshotProtected: Boolean,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var showChangePinDialog by remember { mutableStateOf(false) }
    var showAutoLockDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showScreenshotWarningDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    val autoLockLabel = when (autoLockMs) {
        SettingsRepository.AUTO_LOCK_IMMEDIATELY -> Localization.getString("auto_lock_immediately", language)
        SettingsRepository.AUTO_LOCK_5_MIN -> Localization.getString("auto_lock_5min", language)
        SettingsRepository.AUTO_LOCK_10_MIN -> Localization.getString("auto_lock_10min", language)
        else -> Localization.getString("auto_lock_1min", language)
    }

    val currentLangLabel = if (language == "bn") Localization.getString("lang_bangla", language)
    else Localization.getString("lang_english", language)

    Scaffold(
        containerColor = VaultDarkCanvas,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VaultDarkSurface)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_btn")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = VaultTextPrimary
                    )
                }
                Text(
                    text = Localization.getString("settings_title", language),
                    color = VaultTextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .testTag("settings_screen")
        ) {
            // Security Section
            SettingsSectionHeader(title = Localization.getString("security_section", language))

            SettingsCard {
                SettingsClickableItem(
                    title = Localization.getString("change_pin", language),
                    subtitle = Localization.getString("change_pin_desc", language),
                    icon = Icons.Default.LockReset,
                    testTag = "setting_change_pin",
                    onClick = { showChangePinDialog = true }
                )

                SettingsDivider()

                SettingsToggleItem(
                    title = Localization.getString("biometric_unlock", language),
                    subtitle = Localization.getString("biometric_unlock_desc", language),
                    icon = Icons.Default.Fingerprint,
                    checked = isBiometricEnabled,
                    testTag = "setting_biometric_toggle",
                    onCheckedChange = { settingsRepository.setBiometricEnabled(it) }
                )

                SettingsDivider()

                SettingsClickableItem(
                    title = Localization.getString("auto_lock_title", language),
                    subtitle = autoLockLabel,
                    icon = Icons.Default.LockClock,
                    testTag = "setting_auto_lock",
                    onClick = { showAutoLockDialog = true }
                )

                SettingsDivider()

                SettingsToggleItem(
                    title = Localization.getString("screenshot_protection_title", language),
                    subtitle = Localization.getString("screenshot_protection_desc", language),
                    icon = Icons.Default.Security,
                    checked = isScreenshotProtected,
                    testTag = "setting_screenshot_protection",
                    onCheckedChange = { checked ->
                        if (!checked) {
                            showScreenshotWarningDialog = true
                        } else {
                            settingsRepository.setScreenshotProtected(true)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Appearance & Experience Section
            SettingsSectionHeader(title = Localization.getString("appearance_section", language))

            SettingsCard {
                SettingsToggleItem(
                    title = Localization.getString("sound_title", language),
                    subtitle = Localization.getString("sound_desc", language),
                    icon = Icons.AutoMirrored.Filled.VolumeUp,
                    checked = isSoundEnabled,
                    testTag = "setting_sound_toggle",
                    onCheckedChange = { settingsRepository.setSoundEnabled(it) }
                )

                SettingsDivider()

                SettingsToggleItem(
                    title = Localization.getString("dark_mode_title", language),
                    subtitle = Localization.getString("dark_mode_desc", language),
                    icon = Icons.Default.DarkMode,
                    checked = isDarkMode,
                    testTag = "setting_dark_mode_toggle",
                    onCheckedChange = { settingsRepository.setDarkMode(it) }
                )

                SettingsDivider()

                SettingsClickableItem(
                    title = Localization.getString("language_title", language),
                    subtitle = currentLangLabel,
                    icon = Icons.Default.Language,
                    testTag = "setting_language",
                    onClick = { showLanguageDialog = true }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // About Section
            SettingsSectionHeader(title = Localization.getString("about_section", language))

            SettingsCard {
                SettingsClickableItem(
                    title = Localization.getString("about_section", language),
                    subtitle = Localization.getString("about_version", language),
                    icon = Icons.Default.Info,
                    testTag = "setting_about",
                    onClick = { showAboutDialog = true }
                )
            }

            Spacer(modifier = Modifier.height(36.dp))
        }
    }

    // Change PIN Dialog
    if (showChangePinDialog) {
        ChangePinDialog(
            language = language,
            onDismiss = { showChangePinDialog = false },
            onSuccess = {
                showChangePinDialog = false
                Toast.makeText(
                    context,
                    Localization.getString("pin_changed_success", language),
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }

    // Auto-lock Dialog
    if (showAutoLockDialog) {
        AlertDialog(
            onDismissRequest = { showAutoLockDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Text(
                    text = Localization.getString("auto_lock_title", language),
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    val options = listOf(
                        SettingsRepository.AUTO_LOCK_IMMEDIATELY to Localization.getString("auto_lock_immediately", language),
                        SettingsRepository.AUTO_LOCK_1_MIN to Localization.getString("auto_lock_1min", language),
                        SettingsRepository.AUTO_LOCK_5_MIN to Localization.getString("auto_lock_5min", language),
                        SettingsRepository.AUTO_LOCK_10_MIN to Localization.getString("auto_lock_10min", language)
                    )
                    options.forEach { (durationMs, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    settingsRepository.setAutoLockMs(durationMs)
                                    showAutoLockDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = autoLockMs == durationMs,
                                onClick = {
                                    settingsRepository.setAutoLockMs(durationMs)
                                    showAutoLockDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = VaultEmeraldPrimary)
                            )
                            Text(
                                text = label,
                                color = VaultTextPrimary,
                                fontSize = 15.sp,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAutoLockDialog = false }) {
                    Text(Localization.getString("cancel", language), color = VaultTextSecondary)
                }
            }
        )
    }

    // Language Dialog
    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Text(
                    text = Localization.getString("language_title", language),
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    val languages = listOf("en" to "English", "bn" to "বাংলা")
                    languages.forEach { (code, name) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    settingsRepository.setLanguage(code)
                                    showLanguageDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = language == code,
                                onClick = {
                                    settingsRepository.setLanguage(code)
                                    showLanguageDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = VaultEmeraldPrimary)
                            )
                            Text(
                                text = name,
                                color = VaultTextPrimary,
                                fontSize = 16.sp,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) {
                    Text(Localization.getString("cancel", language), color = VaultTextSecondary)
                }
            }
        )
    }

    // Screenshot Protection Warning Dialog
    if (showScreenshotWarningDialog) {
        AlertDialog(
            onDismissRequest = { showScreenshotWarningDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Text(
                    text = Localization.getString("screenshot_protection_title", language),
                    color = VaultTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = Localization.getString("screenshot_protection_desc", language),
                    color = VaultTextSecondary,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        // User insisted on disabling
                        settingsRepository.setScreenshotProtected(false)
                        showScreenshotWarningDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultDarkCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VaultErrorRed)
                ) {
                    Text("Disable Anyway", color = VaultErrorRed)
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        // Keep secure default
                        settingsRepository.setScreenshotProtected(true)
                        showScreenshotWarningDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VaultEmeraldPrimary)
                ) {
                    Text("Keep Protected", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            containerColor = VaultDarkCard,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = VaultEmeraldGlow,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = Localization.getString("about_section", language),
                        color = VaultTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = Localization.getString("about_version", language),
                        color = VaultEmeraldGlow,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = Localization.getString("about_guarantee_desc", language),
                        color = VaultTextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Hardware Keystore AES-256-GCM\n• Zero network tracking\n• App-private sandbox storage\n• Biometric hardware auth",
                        color = VaultTextMuted,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text(Localization.getString("close", language), color = VaultEmeraldPrimary)
                }
            }
        )
    }
}

@Composable
private fun ChangePinDialog(
    language: String,
    onDismiss: () -> Unit,
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    var currentPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VaultDarkCard,
        title = {
            Text(
                text = Localization.getString("change_pin", language),
                color = VaultTextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = currentPin,
                    onValueChange = { if (it.length <= 6) currentPin = it },
                    label = { Text(Localization.getString("enter_current_pin", language)) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VaultEmeraldPrimary,
                        unfocusedBorderColor = VaultBorder,
                        focusedTextColor = VaultTextPrimary,
                        unfocusedTextColor = VaultTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("change_current_pin_input")
                )

                OutlinedTextField(
                    value = newPin,
                    onValueChange = { if (it.length <= 6) newPin = it },
                    label = { Text(Localization.getString("enter_new_pin", language)) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VaultEmeraldPrimary,
                        unfocusedBorderColor = VaultBorder,
                        focusedTextColor = VaultTextPrimary,
                        unfocusedTextColor = VaultTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("change_new_pin_input")
                )

                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { if (it.length <= 6) confirmPin = it },
                    label = { Text(Localization.getString("confirm_new_pin", language)) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VaultEmeraldPrimary,
                        unfocusedBorderColor = VaultBorder,
                        focusedTextColor = VaultTextPrimary,
                        unfocusedTextColor = VaultTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("change_confirm_pin_input")
                )

                if (errorMsg != null) {
                    Text(
                        text = errorMsg ?: "",
                        color = VaultErrorRed,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (currentPin.length != 6 || newPin.length != 6 || confirmPin.length != 6) {
                        errorMsg = "PINs must be exactly 6 digits."
                        return@Button
                    }
                    val verify = SecurityManager.verifyPin(context, currentPin)
                    if (verify !is SecurityManager.PinVerifyResult.Success) {
                        errorMsg = Localization.getString("pin_incorrect", language)
                        return@Button
                    }
                    if (newPin != confirmPin) {
                        errorMsg = Localization.getString("pin_mismatch", language)
                        return@Button
                    }
                    SecurityManager.setPin(context, newPin)
                    onSuccess()
                },
                colors = ButtonDefaults.buttonColors(containerColor = VaultEmeraldPrimary),
                modifier = Modifier.testTag("submit_change_pin_btn")
            ) {
                Text(Localization.getString("change_pin", language), color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(Localization.getString("cancel", language), color = VaultTextSecondary)
            }
        }
    )
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        color = VaultEmeraldGlow,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(VaultDarkCard)
            .border(1.dp, VaultBorder, RoundedCornerShape(18.dp))
    ) {
        content()
    }
}

@Composable
private fun SettingsClickableItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = VaultTextPrimary, modifier = Modifier.size(20.dp))
            }

            Column {
                Text(text = title, color = VaultTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = subtitle, color = VaultTextSecondary, fontSize = 12.sp)
            }
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = VaultTextMuted,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun SettingsToggleItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f).padding(end = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = VaultTextPrimary, modifier = Modifier.size(20.dp))
            }

            Column {
                Text(text = title, color = VaultTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = subtitle, color = VaultTextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = VaultEmeraldPrimary,
                uncheckedThumbColor = VaultTextMuted,
                uncheckedTrackColor = Color(0xFF1E293B)
            )
        )
    }
}

@Composable
private fun SettingsDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(VaultBorder.copy(alpha = 0.5f))
    )
}
