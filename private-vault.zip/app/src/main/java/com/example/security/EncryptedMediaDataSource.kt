package com.example.security

import android.media.MediaDataSource
import android.util.LruCache
import java.io.File
import java.io.RandomAccessFile
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * High-performance streaming MediaDataSource for encrypted video playback.
 * Performs on-the-fly chunked AES-256-GCM decryption with LRU cache.
 * Never loads the full video into RAM and avoids writing large temporary decrypted files.
 */
class EncryptedMediaDataSource(
    private val encryptedFile: File,
    private val masterKey: SecretKey
) : MediaDataSource() {

    companion object {
        val VLTC_MAGIC = "VLTC".toByteArray(StandardCharsets.US_ASCII)
        const val HEADER_SIZE = 21L // 4 (magic) + 1 (version) + 4 (chunkSize) + 8 (plainSize) + 4 (chunks)
        const val GCM_TAG_BYTES = 16
        const val IV_BYTES = 12
    }

    private var randomAccessFile: RandomAccessFile? = null
    private val fileLock = Any()

    var totalPlainSize: Long = 0L
        private set
    var chunkSize: Int = 256 * 1024
        private set
    var totalChunks: Int = 0
        private set

    // Cache up to 4 decrypted chunks in memory (~1 MB RAM footprint)
    private val chunkCache = object : LruCache<Int, ByteArray>(4) {}

    init {
        openAndParseHeader()
    }

    private fun openAndParseHeader() {
        val raf = RandomAccessFile(encryptedFile, "r")
        randomAccessFile = raf

        if (raf.length() < HEADER_SIZE) {
            throw IllegalArgumentException("File too small to be a valid vault chunked media file")
        }

        raf.seek(0)
        val magic = ByteArray(4)
        raf.readFully(magic)
        if (!magic.contentEquals(VLTC_MAGIC)) {
            throw IllegalArgumentException("Not a valid VLTC chunked video file")
        }

        val version = raf.readByte().toInt()
        if (version != 1) {
            throw IllegalArgumentException("Unsupported VLTC version: $version")
        }

        chunkSize = raf.readInt()
        totalPlainSize = raf.readLong()
        totalChunks = raf.readInt()

        if (chunkSize <= 0 || totalPlainSize < 0 || totalChunks <= 0) {
            throw IllegalArgumentException("Corrupted VLTC header parameters")
        }
    }

    override fun getSize(): Long {
        return totalPlainSize
    }

    override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        if (position >= totalPlainSize) {
            return -1
        }
        if (size <= 0) {
            return 0
        }

        val available = (totalPlainSize - position).toInt()
        val toRead = minOf(size, available)
        var bytesRead = 0

        while (bytesRead < toRead) {
            val currentPos = position + bytesRead
            val chunkIndex = (currentPos / chunkSize).toInt()
            val offsetInChunk = (currentPos % chunkSize).toInt()

            val chunkData = getOrDecryptChunk(chunkIndex) ?: break
            val bytesFromThisChunk = minOf(toRead - bytesRead, chunkData.size - offsetInChunk)
            if (bytesFromThisChunk <= 0) break

            System.arraycopy(chunkData, offsetInChunk, buffer, offset + bytesRead, bytesFromThisChunk)
            bytesRead += bytesFromThisChunk
        }

        return if (bytesRead > 0) bytesRead else -1
    }

    private fun getOrDecryptChunk(chunkIndex: Int): ByteArray? {
        if (chunkIndex < 0 || chunkIndex >= totalChunks) return null

        synchronized(chunkCache) {
            chunkCache.get(chunkIndex)?.let { return it }
        }

        val plainChunkSize = if (chunkIndex == totalChunks - 1) {
            val rem = totalPlainSize - (totalChunks - 1).toLong() * chunkSize
            rem.toInt()
        } else {
            chunkSize
        }

        val cipherChunkDiskSize = IV_BYTES + plainChunkSize + GCM_TAG_BYTES
        val chunkDiskOffset = HEADER_SIZE + chunkIndex.toLong() * (IV_BYTES + chunkSize + GCM_TAG_BYTES)

        val rawBytes = ByteArray(cipherChunkDiskSize)
        val raf = randomAccessFile ?: return null

        synchronized(fileLock) {
            try {
                raf.seek(chunkDiskOffset)
                raf.readFully(rawBytes)
            } catch (e: Exception) {
                e.printStackTrace()
                return null
            }
        }

        return try {
            val iv = ByteArray(IV_BYTES)
            System.arraycopy(rawBytes, 0, iv, 0, IV_BYTES)

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val spec = GCMParameterSpec(GCM_TAG_BYTES * 8, iv)
            cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)

            val decrypted = cipher.doFinal(rawBytes, IV_BYTES, rawBytes.size - IV_BYTES)

            synchronized(chunkCache) {
                chunkCache.put(chunkIndex, decrypted)
            }
            decrypted
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    override fun close() {
        synchronized(fileLock) {
            try {
                randomAccessFile?.close()
            } catch (_: Exception) {}
            randomAccessFile = null
        }
        synchronized(chunkCache) {
            chunkCache.evictAll()
        }
    }
}
