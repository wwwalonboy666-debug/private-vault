package com.example.security

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/**
 * Handles military-grade authenticated local encryption (AES-256-GCM)
 * using Android Keystore and strong cryptographic primitives.
 */
object CryptoManager {
    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val MASTER_KEY_ALIAS = "private_vault_master_key_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH = 128
    private const val IV_LENGTH_BYTES = 12
    private const val PBKDF2_ITERATIONS = 12000
    private const val PIN_KEY_LENGTH = 256

    private val keyStore: KeyStore by lazy {
        KeyStore.getInstance(KEYSTORE_PROVIDER).apply {
            load(null)
        }
    }

    private fun getOrCreateMasterKey(): SecretKey {
        if (keyStore.containsAlias(MASTER_KEY_ALIAS)) {
            val keyEntry = keyStore.getEntry(MASTER_KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
            if (keyEntry != null) {
                return keyEntry.secretKey
            }
        }

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build()

        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    /**
     * Hashes a 6-digit PIN securely using PBKDF2WithHmacSHA256 with a random salt.
     * Never store the plain PIN!
     */
    fun hashPin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, PIN_KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    fun generateSalt(): ByteArray {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        return salt
    }

    /**
     * Encrypts input stream content into target file using AES/GCM/NoPadding.
     * Format: [12 bytes IV][Encrypted Ciphertext with 16 bytes GCM Auth Tag]
     */
    fun encryptStreamToFile(inputStream: InputStream, destinationFile: File): Long {
        val masterKey = getOrCreateMasterKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, masterKey)
        val iv = cipher.iv

        destinationFile.parentFile?.mkdirs()
        FileOutputStream(destinationFile).use { fos ->
            // Prepend IV
            fos.write(iv)
            CipherOutputStream(fos, cipher).use { cos ->
                val buffer = ByteArray(32 * 1024)
                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    cos.write(buffer, 0, bytesRead)
                }
                cos.flush()
            }
        }
        return destinationFile.length()
    }

    /**
     * Decrypts encrypted file content to destination output stream.
     * Verifies GCM auth tag automatically; throws if tampered.
     */
    fun decryptFileToStream(sourceFile: File, outputStream: java.io.OutputStream) {
        val masterKey = getOrCreateMasterKey()
        FileInputStream(sourceFile).use { fis ->
            val iv = ByteArray(IV_LENGTH_BYTES)
            val ivRead = fis.read(iv)
            if (ivRead != IV_LENGTH_BYTES) {
                throw IllegalStateException("Invalid encrypted vault file header")
            }

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)

            CipherInputStream(fis, cipher).use { cis ->
                val buffer = ByteArray(32 * 1024)
                var bytesRead: Int
                while (cis.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                }
                outputStream.flush()
            }
        }
    }

    /**
     * Decrypts an encrypted image file into an in-memory Bitmap.
     * Keeps decoded bytes in private volatile memory.
     */
    fun decryptImageToBitmap(sourceFile: File, sampleSize: Int = 1): Bitmap? {
        val masterKey = getOrCreateMasterKey()
        return try {
            FileInputStream(sourceFile).use { fis ->
                val iv = ByteArray(IV_LENGTH_BYTES)
                val ivRead = fis.read(iv)
                if (ivRead != IV_LENGTH_BYTES) return null

                val cipher = Cipher.getInstance(TRANSFORMATION)
                val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
                cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)

                CipherInputStream(fis, cipher).use { cis ->
                    val options = BitmapFactory.Options().apply {
                        inSampleSize = sampleSize
                    }
                    BitmapFactory.decodeStream(cis, null, options)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Verifies ciphertext file integrity and GCM authentication tag.
     */
    fun verifyEncryptedFile(file: File): Boolean {
        if (!file.exists() || file.length() < (IV_LENGTH_BYTES + 16)) return false
        val masterKey = getOrCreateMasterKey()
        return try {
            FileInputStream(file).use { fis ->
                val iv = ByteArray(IV_LENGTH_BYTES)
                val ivRead = fis.read(iv)
                if (ivRead != IV_LENGTH_BYTES) return false

                val cipher = Cipher.getInstance(TRANSFORMATION)
                val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
                cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)

                CipherInputStream(fis, cipher).use { cis ->
                    val buffer = ByteArray(8 * 1024)
                    while (cis.read(buffer) != -1) {
                        // verify entire stream auth tag
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Generates a compressed encrypted thumbnail for fast grid scrolling.
     */
    fun createEncryptedThumbnail(
        context: Context,
        originalUri: Uri,
        isVideo: Boolean,
        thumbFile: File
    ): Boolean {
        return try {
            val bitmap: Bitmap? = if (isVideo) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, originalUri)
                    retriever.getFrameAtTime(1000000)
                } finally {
                    try { retriever.release() } catch (_: Exception) {}
                }
            } else {
                context.contentResolver.openInputStream(originalUri)?.use { input ->
                    val options = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    BitmapFactory.decodeStream(input, null, options)
                    val maxDim = maxOf(options.outWidth, options.outHeight)
                    var sample = 1
                    while (maxDim / sample > 400) {
                        sample *= 2
                    }
                    context.contentResolver.openInputStream(originalUri)?.use { actualInput ->
                        val actualOptions = BitmapFactory.Options().apply {
                            inSampleSize = sample
                        }
                        BitmapFactory.decodeStream(actualInput, null, actualOptions)
                    }
                }
            }

            if (bitmap != null) {
                val scaled = if (bitmap.width > 400 || bitmap.height > 400) {
                    val ratio = 400f / maxOf(bitmap.width, bitmap.height)
                    Bitmap.createScaledBitmap(
                        bitmap,
                        (bitmap.width * ratio).toInt().coerceAtLeast(1),
                        (bitmap.height * ratio).toInt().coerceAtLeast(1),
                        true
                    )
                } else bitmap

                val baos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 75, baos)
                val thumbBytes = baos.toByteArray()

                thumbBytes.inputStream().use { stream ->
                    encryptStreamToFile(stream, thumbFile)
                }
                true
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Decrypts encrypted media to a temporary cache file for video playback,
     * ensuring it is marked deleteOnExit and stored in cache.
     */
    fun decryptToTempFile(context: Context, sourceFile: File, prefix: String, extension: String): File {
        val tempFile = File.createTempFile("vault_${prefix}_", extension, context.cacheDir)
        tempFile.deleteOnExit()
        FileOutputStream(tempFile).use { fos ->
            decryptFileToStream(sourceFile, fos)
        }
        return tempFile
    }
}
