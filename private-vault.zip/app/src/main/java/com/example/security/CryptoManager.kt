package com.example.security

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/**
 * Handles military-grade authenticated local encryption (AES-256-GCM)
 * using Android Keystore and strong cryptographic primitives.
 */
object CryptoManager {
    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val MASTER_KEY_ALIAS = "private_vault_master_key_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH = 128
    private const val IV_LENGTH_BYTES = 12
    private const val PBKDF2_ITERATIONS = 12000
    private const val PIN_KEY_LENGTH = 256

    private val keyStore: KeyStore by lazy {
        KeyStore.getInstance(KEYSTORE_PROVIDER).apply {
            load(null)
        }
    }

    private fun getOrCreateMasterKey(): SecretKey {
        if (keyStore.containsAlias(MASTER_KEY_ALIAS)) {
            val keyEntry = keyStore.getEntry(MASTER_KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
            if (keyEntry != null) {
                return keyEntry.secretKey
            }
        }

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build()

        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    /**
     * Hashes a 6-digit PIN securely using PBKDF2WithHmacSHA256 with a random salt.
     * Never store the plain PIN!
     */
    fun hashPin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, PIN_KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    fun generateSalt(): ByteArray {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        return salt
    }

    /**
     * Checks whether the encrypted file was stored in the chunked streaming format.
     */
    fun isChunkedEncrypted(file: File): Boolean {
        if (!file.exists() || file.length() < EncryptedMediaDataSource.HEADER_SIZE) return false
        return try {
            FileInputStream(file).use { fis ->
                val magic = ByteArray(4)
                val read = fis.read(magic)
                read == 4 && magic.contentEquals(EncryptedMediaDataSource.VLTC_MAGIC)
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Creates a streaming EncryptedMediaDataSource for fast, random-access video playback.
     */
    fun createEncryptedMediaDataSource(file: File): EncryptedMediaDataSource {
        return EncryptedMediaDataSource(file, getOrCreateMasterKey())
    }

    /**
     * Encrypts input stream into target file using chunked AES-256-GCM.
     * Each chunk is authenticated independently, enabling instant streaming playback
     * and seeking without decrypting the entire file into RAM or disk.
     */
    fun encryptStreamChunked(
        inputStream: InputStream,
        destinationFile: File,
        estimatedTotalBytes: Long = -1L,
        chunkSize: Int = 256 * 1024,
        onProgress: ((bytesRead: Long, totalBytes: Long) -> Unit)? = null
    ): Long {
        val masterKey = getOrCreateMasterKey()
        destinationFile.parentFile?.mkdirs()

        val secureRandom = SecureRandom()
        var totalPlainBytes = 0L
        var chunkCount = 0

        // Use RandomAccessFile to write placeholder header, then stream chunks, then finalize header
        java.io.RandomAccessFile(destinationFile, "rw").use { raf ->
            raf.setLength(0L) // truncate if existing

            // Placeholder header: 21 bytes
            raf.write(EncryptedMediaDataSource.VLTC_MAGIC)
            raf.writeByte(1) // version
            raf.writeInt(chunkSize)
            raf.writeLong(0L) // plainSize placeholder
            raf.writeInt(0)   // chunkCount placeholder

            val bufferedIn = java.io.BufferedInputStream(inputStream, 128 * 1024)
            val chunkBuffer = ByteArray(chunkSize)

            while (true) {
                var bytesReadInChunk = 0
                while (bytesReadInChunk < chunkSize) {
                    val r = bufferedIn.read(chunkBuffer, bytesReadInChunk, chunkSize - bytesReadInChunk)
                    if (r == -1) break
                    bytesReadInChunk += r
                }

                if (bytesReadInChunk == 0) {
                    // Reached EOF
                    break
                }

                // Generate random 12-byte IV for this chunk
                val iv = ByteArray(EncryptedMediaDataSource.IV_BYTES)
                secureRandom.nextBytes(iv)

                val cipher = Cipher.getInstance(TRANSFORMATION)
                val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
                cipher.init(Cipher.ENCRYPT_MODE, masterKey, spec)

                val cipherBytes = cipher.doFinal(chunkBuffer, 0, bytesReadInChunk)

                // Write IV + Ciphertext (which includes 16-byte GCM tag)
                raf.write(iv)
                raf.write(cipherBytes)

                totalPlainBytes += bytesReadInChunk
                chunkCount++

                onProgress?.invoke(totalPlainBytes, estimatedTotalBytes)
            }

            // Finalize header with exact plain byte size and chunk count
            raf.seek(9) // after magic(4) + ver(1) + chunkSize(4)
            raf.writeLong(totalPlainBytes)
            raf.writeInt(chunkCount)
        }

        return destinationFile.length()
    }

    /**
     * Encrypts input stream content into target file using AES/GCM/NoPadding.
     * Format: [12 bytes IV][Encrypted Ciphertext with 16 bytes GCM Auth Tag]
     */
    fun encryptStreamToFile(
        inputStream: InputStream,
        destinationFile: File,
        totalBytes: Long = -1L,
        onProgress: ((bytesRead: Long, totalBytes: Long) -> Unit)? = null
    ): Long {
        val masterKey = getOrCreateMasterKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, masterKey)
        val iv = cipher.iv

        destinationFile.parentFile?.mkdirs()
        java.io.BufferedOutputStream(FileOutputStream(destinationFile), 128 * 1024).use { fos ->
            // Prepend IV
            fos.write(iv)
            CipherOutputStream(fos, cipher).use { cos ->
                val bufferedIn = java.io.BufferedInputStream(inputStream, 128 * 1024)
                val buffer = ByteArray(128 * 1024)
                var bytesRead: Int
                var totalRead = 0L
                while (bufferedIn.read(buffer).also { bytesRead = it } != -1) {
                    cos.write(buffer, 0, bytesRead)
                    totalRead += bytesRead
                    onProgress?.invoke(totalRead, totalBytes)
                }
                cos.flush()
            }
        }
        return destinationFile.length()
    }

    /**
     * Decrypts encrypted file content to destination output stream.
     * Supports both chunked (VLTC) and legacy formats seamlessly.
     */
    fun decryptFileToStream(sourceFile: File, outputStream: java.io.OutputStream) {
        if (isChunkedEncrypted(sourceFile)) {
            decryptChunkedFileToStream(sourceFile, outputStream)
        } else {
            decryptLegacyFileToStream(sourceFile, outputStream)
        }
    }

    private fun decryptChunkedFileToStream(sourceFile: File, outputStream: java.io.OutputStream) {
        val masterKey = getOrCreateMasterKey()
        val bufferedOut = java.io.BufferedOutputStream(outputStream, 128 * 1024)

        java.io.RandomAccessFile(sourceFile, "r").use { raf ->
            raf.seek(0)
            val magic = ByteArray(4)
            raf.readFully(magic)
            val version = raf.readByte().toInt()
            val chunkSize = raf.readInt()
            val totalPlainSize = raf.readLong()
            val totalChunks = raf.readInt()

            for (i in 0 until totalChunks) {
                val plainChunkSize = if (i == totalChunks - 1) {
                    (totalPlainSize - (totalChunks - 1).toLong() * chunkSize).toInt()
                } else {
                    chunkSize
                }

                val cipherChunkSize = EncryptedMediaDataSource.IV_BYTES + plainChunkSize + EncryptedMediaDataSource.GCM_TAG_BYTES
                val rawBytes = ByteArray(cipherChunkSize)
                raf.readFully(rawBytes)

                val iv = ByteArray(EncryptedMediaDataSource.IV_BYTES)
                System.arraycopy(rawBytes, 0, iv, 0, EncryptedMediaDataSource.IV_BYTES)

                val cipher = Cipher.getInstance(TRANSFORMATION)
                val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
                cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)

                val decrypted = cipher.doFinal(rawBytes, EncryptedMediaDataSource.IV_BYTES, rawBytes.size - EncryptedMediaDataSource.IV_BYTES)
                bufferedOut.write(decrypted)
            }
            bufferedOut.flush()
        }
    }

    private fun decryptLegacyFileToStream(sourceFile: File, outputStream: java.io.OutputStream) {
        val masterKey = getOrCreateMasterKey()
        java.io.BufferedInputStream(FileInputStream(sourceFile), 128 * 1024).use { fis ->
            val iv = ByteArray(IV_LENGTH_BYTES)
            val ivRead = fis.read(iv)
            if (ivRead != IV_LENGTH_BYTES) {
                throw IllegalStateException("Invalid encrypted vault file header")
            }

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)

            val bufferedOut = java.io.BufferedOutputStream(outputStream, 128 * 1024)
            CipherInputStream(fis, cipher).use { cis ->
                val buffer = ByteArray(128 * 1024)
                var bytesRead: Int
                while (cis.read(buffer).also { bytesRead = it } != -1) {
                    bufferedOut.write(buffer, 0, bytesRead)
                }
                bufferedOut.flush()
            }
        }
    }

    /**
     * Decrypts an encrypted image file into an in-memory Bitmap.
     * Keeps decoded bytes in private volatile memory.
     */
    fun decryptImageToBitmap(sourceFile: File, sampleSize: Int = 1): Bitmap? {
        val masterKey = getOrCreateMasterKey()
        return try {
            if (isChunkedEncrypted(sourceFile)) {
                val baos = ByteArrayOutputStream()
                decryptChunkedFileToStream(sourceFile, baos)
                val bytes = baos.toByteArray()
                val options = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
            } else {
                java.io.BufferedInputStream(FileInputStream(sourceFile), 128 * 1024).use { fis ->
                    val iv = ByteArray(IV_LENGTH_BYTES)
                    val ivRead = fis.read(iv)
                    if (ivRead != IV_LENGTH_BYTES) return null

                    val cipher = Cipher.getInstance(TRANSFORMATION)
                    val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
                    cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)

                    CipherInputStream(fis, cipher).use { cis ->
                        val options = BitmapFactory.Options().apply {
                            inSampleSize = sampleSize
                        }
                        BitmapFactory.decodeStream(cis, null, options)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Verifies ciphertext file integrity and GCM authentication tag.
     */
    fun verifyEncryptedFile(file: File): Boolean {
        if (!file.exists()) return false
        val masterKey = getOrCreateMasterKey()

        return try {
            if (isChunkedEncrypted(file)) {
                java.io.RandomAccessFile(file, "r").use { raf ->
                    raf.seek(0)
                    val magic = ByteArray(4)
                    raf.readFully(magic)
                    val version = raf.readByte().toInt()
                    val chunkSize = raf.readInt()
                    val totalPlainSize = raf.readLong()
                    val totalChunks = raf.readInt()

                    for (i in 0 until totalChunks) {
                        val plainChunkSize = if (i == totalChunks - 1) {
                            (totalPlainSize - (totalChunks - 1).toLong() * chunkSize).toInt()
                        } else {
                            chunkSize
                        }
                        val cipherChunkSize = EncryptedMediaDataSource.IV_BYTES + plainChunkSize + EncryptedMediaDataSource.GCM_TAG_BYTES
                        val rawBytes = ByteArray(cipherChunkSize)
                        raf.readFully(rawBytes)

                        val iv = ByteArray(EncryptedMediaDataSource.IV_BYTES)
                        System.arraycopy(rawBytes, 0, iv, 0, EncryptedMediaDataSource.IV_BYTES)

                        val cipher = Cipher.getInstance(TRANSFORMATION)
                        val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
                        cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)
                        // Calling doFinal verifies the GCM tag for this chunk
                        cipher.doFinal(rawBytes, EncryptedMediaDataSource.IV_BYTES, rawBytes.size - EncryptedMediaDataSource.IV_BYTES)
                    }
                }
                true
            } else {
                if (file.length() < (IV_LENGTH_BYTES + 16)) return false
                java.io.BufferedInputStream(FileInputStream(file), 128 * 1024).use { fis ->
                    val iv = ByteArray(IV_LENGTH_BYTES)
                    val ivRead = fis.read(iv)
                    if (ivRead != IV_LENGTH_BYTES) return false

                    val cipher = Cipher.getInstance(TRANSFORMATION)
                    val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
                    cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)

                    CipherInputStream(fis, cipher).use { cis ->
                        val buffer = ByteArray(128 * 1024)
                        while (cis.read(buffer) != -1) {
                            // verify entire stream auth tag
                        }
                    }
                }
                true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Generates a compressed encrypted thumbnail for fast grid scrolling.
     */
    fun createEncryptedThumbnail(
        context: Context,
        originalUri: Uri,
        isVideo: Boolean,
        thumbFile: File
    ): Boolean {
        return try {
            val bitmap: Bitmap? = if (isVideo) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, originalUri)
                    // OPTION_CLOSEST_SYNC retrieves keyframe instantly without decoding seconds of video
                    retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: retriever.frameAtTime
                } finally {
                    try { retriever.release() } catch (_: Exception) {}
                }
            } else {
                context.contentResolver.openInputStream(originalUri)?.use { input ->
                    val options = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    BitmapFactory.decodeStream(input, null, options)
                    val maxDim = maxOf(options.outWidth, options.outHeight)
                    var sample = 1
                    while (maxDim / sample > 400) {
                        sample *= 2
                    }
                    context.contentResolver.openInputStream(originalUri)?.use { actualInput ->
                        val actualOptions = BitmapFactory.Options().apply {
                            inSampleSize = sample
                        }
                        BitmapFactory.decodeStream(actualInput, null, actualOptions)
                    }
                }
            }

            if (bitmap != null) {
                val scaled = if (bitmap.width > 400 || bitmap.height > 400) {
                    val ratio = 400f / maxOf(bitmap.width, bitmap.height)
                    Bitmap.createScaledBitmap(
                        bitmap,
                        (bitmap.width * ratio).toInt().coerceAtLeast(1),
                        (bitmap.height * ratio).toInt().coerceAtLeast(1),
                        true
                    )
                } else bitmap

                val baos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 75, baos)
                val thumbBytes = baos.toByteArray()

                thumbBytes.inputStream().use { stream ->
                    encryptStreamToFile(stream, thumbFile)
                }
                true
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Decrypts encrypted media to a temporary cache file using buffered I/O,
     * ensuring it is marked deleteOnExit and stored in cache.
     */
    fun decryptToTempFile(context: Context, sourceFile: File, prefix: String, extension: String): File {
        val tempFile = File.createTempFile("vault_${prefix}_", extension, context.cacheDir)
        tempFile.deleteOnExit()
        FileOutputStream(tempFile).use { fos ->
            decryptFileToStream(sourceFile, fos)
        }
        return tempFile
    }
}
