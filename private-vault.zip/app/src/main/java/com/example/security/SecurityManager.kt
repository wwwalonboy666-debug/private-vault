package com.example.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object SecurityManager {
    private const val PREFS_NAME = "private_vault_sec_prefs"
    private const val KEY_PIN_HASH = "pin_hash"
    private const val KEY_PIN_SALT = "pin_salt"
    private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
    private const val KEY_LOCKOUT_TIMESTAMP = "lockout_timestamp"
    private const val KEY_LAST_ACTIVE_TIMESTAMP = "last_active_timestamp"

    private const val MAX_FAILED_ATTEMPTS = 5
    private const val LOCKOUT_DURATION_MS = 30_000L // 30 seconds

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isPinSet(context: Context): Boolean {
        val prefs = getPrefs(context)
        return prefs.contains(KEY_PIN_HASH) && prefs.contains(KEY_PIN_SALT)
    }

    fun setPin(context: Context, pin: String): Boolean {
        if (pin.length != 6 || !pin.all { it.isDigit() }) return false
        val salt = CryptoManager.generateSalt()
        val hash = CryptoManager.hashPin(pin, salt)
        getPrefs(context).edit()
            .putString(KEY_PIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_PIN_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_TIMESTAMP, 0L)
            .apply()
        return true
    }

    data class LockoutStatus(
        val isLockedOut: Boolean,
        val remainingSeconds: Int
    )

    fun checkLockoutStatus(context: Context): LockoutStatus {
        val prefs = getPrefs(context)
        val lockoutTime = prefs.getLong(KEY_LOCKOUT_TIMESTAMP, 0L)
        if (lockoutTime > 0) {
            val elapsed = System.currentTimeMillis() - lockoutTime
            if (elapsed < LOCKOUT_DURATION_MS) {
                val remainingSec = ((LOCKOUT_DURATION_MS - elapsed) / 1000).toInt() + 1
                return LockoutStatus(true, remainingSec)
            } else {
                // Lockout expired, reset lockout timestamp but keep attempts tracked
                prefs.edit().putLong(KEY_LOCKOUT_TIMESTAMP, 0L).putInt(KEY_FAILED_ATTEMPTS, 0).apply()
            }
        }
        return LockoutStatus(false, 0)
    }

    sealed class PinVerifyResult {
        object Success : PinVerifyResult()
        object Incorrect : PinVerifyResult()
        data class LockedOut(val remainingSeconds: Int) : PinVerifyResult()
    }

    fun verifyPin(context: Context, enteredPin: String): PinVerifyResult {
        val lockout = checkLockoutStatus(context)
        if (lockout.isLockedOut) {
            return PinVerifyResult.LockedOut(lockout.remainingSeconds)
        }

        val prefs = getPrefs(context)
        val saltBase64 = prefs.getString(KEY_PIN_SALT, null)
        val hashBase64 = prefs.getString(KEY_PIN_HASH, null)

        if (saltBase64 == null || hashBase64 == null) {
            return PinVerifyResult.Incorrect
        }

        val salt = Base64.decode(saltBase64, Base64.NO_WRAP)
        val storedHash = Base64.decode(hashBase64, Base64.NO_WRAP)
        val enteredHash = CryptoManager.hashPin(enteredPin, salt)

        val matches = storedHash.contentEquals(enteredHash)
        if (matches) {
            // Reset failed counter
            prefs.edit()
                .putInt(KEY_FAILED_ATTEMPTS, 0)
                .putLong(KEY_LOCKOUT_TIMESTAMP, 0L)
                .putLong(KEY_LAST_ACTIVE_TIMESTAMP, System.currentTimeMillis())
                .apply()
            return PinVerifyResult.Success
        } else {
            val failed = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
            val editor = prefs.edit().putInt(KEY_FAILED_ATTEMPTS, failed)
            if (failed >= MAX_FAILED_ATTEMPTS) {
                editor.putLong(KEY_LOCKOUT_TIMESTAMP, System.currentTimeMillis())
                editor.apply()
                return PinVerifyResult.LockedOut((LOCKOUT_DURATION_MS / 1000).toInt())
            }
            editor.apply()
            return PinVerifyResult.Incorrect
        }
    }

    fun canUseBiometrics(context: Context): Boolean {
        return try {
            val biometricManager = BiometricManager.from(context)
            val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
            biometricManager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
        } catch (e: Exception) {
            false
        }
    }

    fun promptBiometric(
        activity: FragmentActivity,
        title: String,
        subtitle: String,
        negativeButtonText: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            val executor = ContextCompat.getMainExecutor(activity)
            val prompt = BiometricPrompt(
                activity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        updateLastActive(activity)
                        onSuccess()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        // User canceled or pin fallback
                        onError(errString.toString())
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        onError("Authentication failed")
                    }
                }
            )

            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setNegativeButtonText(negativeButtonText)
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build()

            prompt.authenticate(promptInfo)
        } catch (e: Exception) {
            onError(e.message ?: "Biometric unavailable")
        }
    }

    fun updateLastActive(context: Context) {
        getPrefs(context).edit().putLong(KEY_LAST_ACTIVE_TIMESTAMP, System.currentTimeMillis()).apply()
    }

    fun shouldAutoLock(context: Context, timeoutMs: Long): Boolean {
        if (timeoutMs == 0L) return true // Lock immediately
        val lastActive = getPrefs(context).getLong(KEY_LAST_ACTIVE_TIMESTAMP, 0L)
        if (lastActive == 0L) return true
        return (System.currentTimeMillis() - lastActive) > timeoutMs
    }
}
